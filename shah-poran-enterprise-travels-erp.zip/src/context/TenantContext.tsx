import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Tenant,
  Account,
  JournalEntry,
  Customer,
  FlightTicket,
  UmrahPackage,
  VisaApplication,
  AuditLog,
  TenantStatus,
} from '../types';
import {
  INITIAL_TENANTS,
  INITIAL_ACCOUNTS,
  INITIAL_JOURNAL_ENTRIES,
  INITIAL_CUSTOMERS,
  INITIAL_TICKETS,
  INITIAL_UMRAH_PACKAGES,
  INITIAL_VISA_APPLICATIONS,
  INITIAL_AUDIT_LOGS,
} from '../data/mockDatabase';
import { postingEngine, PostJournalInput } from '../services/accounting/postingEngine';

interface TenantContextType {
  tenants: Tenant[];
  currentTenant: Tenant | null; // null represents Platform Super Admin (admin.shahporan.com)
  isSuperAdmin: boolean;
  activeDomain: string;
  simulatedEdgeHeaders: {
    host: string;
    tenantDomain: string;
    tenantSlug: string;
    dbSessionTenantId: string;
  };
  switchTenant: (tenantId: string | null) => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
  updateTenantStatus: (tenantId: string, status: TenantStatus, reason?: string) => void;
  updateTenantBranding: (tenantId: string, branding: Partial<Tenant['branding']>) => void;
  
  // Data entities
  accounts: Account[];
  journalEntries: JournalEntry[];
  customers: Customer[];
  flightTickets: FlightTicket[];
  umrahPackages: UmrahPackage[];
  visaApplications: VisaApplication[];
  auditLogs: AuditLog[];

  // Actions
  issueFlightTicket: (ticket: Omit<FlightTicket, 'id' | 'createdAt' | 'tenantId' | 'status'>) => { ticket: FlightTicket; journalEntry: JournalEntry };
  createManualJournalEntry: (input: Omit<PostJournalInput, 'tenantId' | 'currency' | 'userId'>) => JournalEntry;
  addCustomer: (customer: Omit<Customer, 'id' | 'createdAt' | 'tenantId'>) => Customer;
  addUmrahPackage: (pkg: Omit<UmrahPackage, 'id' | 'tenantId'>) => UmrahPackage;
  updateUmrahPackageStatus: (id: string, status: UmrahPackage['status']) => void;
  addVisaApplication: (app: Omit<VisaApplication, 'id' | 'tenantId' | 'submissionDate'>) => VisaApplication;
  updateVisaStatus: (id: string, status: VisaApplication['status']) => void;
  recordAuditLog: (action: string, entityType: string, entityId: string, details: string) => void;
}

const TenantContext = createContext<TenantContextType | undefined>(undefined);

export const TenantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [tenants, setTenants] = useState<Tenant[]>(INITIAL_TENANTS);
  // Default to Agency Alpha Travels
  const [currentTenantId, setCurrentTenantId] = useState<string | null>(INITIAL_TENANTS[0].id);

  const [accounts, setAccounts] = useState<Account[]>(INITIAL_ACCOUNTS);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [customers, setCustomers] = useState<Customer[]>(INITIAL_CUSTOMERS);
  const [flightTickets, setFlightTickets] = useState<FlightTicket[]>(INITIAL_TICKETS);
  const [umrahPackages, setUmrahPackages] = useState<UmrahPackage[]>(INITIAL_UMRAH_PACKAGES);
  const [visaApplications, setVisaApplications] = useState<VisaApplication[]>(INITIAL_VISA_APPLICATIONS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);

  // Theme state: dark / light
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('shahporan_theme');
      if (saved) return saved === 'dark';
    }
    return true; // Default to dark mode
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      document.body.classList.add('dark');
    } else {
      root.classList.remove('dark');
      document.body.classList.remove('dark');
    }
    localStorage.setItem('shahporan_theme', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  const toggleTheme = () => {
    setIsDarkMode(prev => !prev);
  };

  const currentTenant = tenants.find(t => t.id === currentTenantId) || null;
  const isSuperAdmin = currentTenant === null;

  // Sync Dynamic CSS Variables for Theme Hydration (Section 5.2)
  useEffect(() => {
    const root = document.documentElement;
    if (currentTenant) {
      root.style.setProperty('--brand-primary', currentTenant.branding.primaryColor);
      root.style.setProperty('--brand-secondary', currentTenant.branding.secondaryColor);
      root.style.setProperty('--brand-accent', currentTenant.branding.accentColor);
    } else {
      // Platform Super Admin Theme
      root.style.setProperty('--brand-primary', '#3B82F6');
      root.style.setProperty('--brand-secondary', '#8B5CF6');
      root.style.setProperty('--brand-accent', '#10B981');
    }
  }, [currentTenant]);

  const activeDomain = isSuperAdmin
    ? 'admin.shahporan.com'
    : currentTenant?.customDomain || `${currentTenant?.slug}.shahporan.com`;

  const simulatedEdgeHeaders = {
    host: activeDomain,
    tenantDomain: currentTenant?.customDomain || 'none',
    tenantSlug: currentTenant?.slug || 'platform-super-admin',
    dbSessionTenantId: currentTenant?.id || '00000000-0000-0000-0000-000000000000 (UNSET)',
  };

  const switchTenant = (tenantId: string | null) => {
    setCurrentTenantId(tenantId);
    if (tenantId) {
      const target = tenants.find(t => t.id === tenantId);
      recordAuditLog(
        'TENANT_CONTEXT_SWITCH',
        'Tenant',
        tenantId,
        `User switched operational context to [${target?.name}] with RLS tenant_id = ${tenantId}`
      );
    } else {
      recordAuditLog(
        'SUPER_ADMIN_MODE_ENTERED',
        'Platform',
        'shahporan-hq',
        'User entered Shah Poran Platform Super Admin control plane'
      );
    }
  };

  const updateTenantStatus = (tenantId: string, status: TenantStatus, reason?: string) => {
    setTenants(prev =>
      prev.map(t => {
        if (t.id === tenantId) {
          return {
            ...t,
            status,
            rejectionReason: reason || t.rejectionReason,
            updatedAt: new Date().toISOString(),
          };
        }
        return t;
      })
    );
    recordAuditLog(
      'TENANT_STATUS_UPDATED',
      'Tenant',
      tenantId,
      `Super Admin transitioned tenant [${tenantId}] status to ${status}${reason ? ` Reason: ${reason}` : ''}`
    );
  };

  const updateTenantBranding = (tenantId: string, branding: Partial<Tenant['branding']>) => {
    setTenants(prev =>
      prev.map(t => {
        if (t.id === tenantId) {
          return {
            ...t,
            branding: {
              ...t.branding,
              ...branding,
            },
            updatedAt: new Date().toISOString(),
          };
        }
        return t;
      })
    );
    recordAuditLog(
      'TENANT_BRANDING_UPDATED',
      'TenantBranding',
      tenantId,
      `Updated white-label theme tokens for agency [${tenantId}]`
    );
  };

  const recordAuditLog = (action: string, entityType: string, entityId: string, details: string) => {
    const newLog: AuditLog = {
      id: `aud-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      tenantId: currentTenant?.id || '00000000-0000-0000-0000-000000000000',
      actorEmail: isSuperAdmin ? 'superadmin@shahporan.com' : `admin@${currentTenant?.slug}.com`,
      action,
      entityType,
      entityId,
      timestamp: new Date().toISOString(),
      clientIp: '103.205.180.12',
      details,
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  // Automated Double-Entry Flight Ticket Issuance
  const issueFlightTicket = (
    ticketData: Omit<FlightTicket, 'id' | 'createdAt' | 'tenantId' | 'status'>
  ) => {
    if (!currentTenant) {
      throw new Error('Cannot issue ticket outside of an active agency tenant context.');
    }

    const ticketId = `tkt-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    
    // Find relevant ledger accounts for this tenant
    const tenantAccounts = accounts.filter(a => a.tenantId === currentTenant.id);
    const arAccount = tenantAccounts.find(a => a.code === '1030') || tenantAccounts.find(a => a.type === 'ASSET');
    const revAccount = tenantAccounts.find(a => a.code === '4010') || tenantAccounts.find(a => a.type === 'REVENUE');
    const cosAccount = tenantAccounts.find(a => a.code === '5010') || tenantAccounts.find(a => a.type === 'EXPENSE');
    const apAccount = tenantAccounts.find(a => a.code === '2010') || tenantAccounts.find(a => a.type === 'LIABILITY');

    if (!arAccount || !revAccount || !cosAccount || !apAccount) {
      throw new Error('Tenant chart of accounts missing required accounts for flight transaction.');
    }

    // Prepare balanced 4-line journal entry:
    // 1. DR Accounts Receivable (Selling Price)
    // 2. CR Flight Revenue (Selling Price)
    // 3. DR Cost of Sales (Net Cost)
    // 4. CR Airline Payable BSP (Net Cost)
    const journalInput: PostJournalInput = {
      tenantId: currentTenant.id,
      currency: currentTenant.currency,
      userId: `agent@${currentTenant.slug}.com`,
      entryDate: new Date().toISOString().split('T')[0],
      memo: `Flight ticket issuance ${ticketData.ticketNumber} (${ticketData.airlineCode} ${ticketData.route}) for PNR ${ticketData.pnr}`,
      referenceType: 'FLIGHT_TICKET',
      referenceId: ticketId,
      lines: [
        {
          accountId: arAccount.id,
          accountCode: arAccount.code,
          accountName: arAccount.name,
          debit: ticketData.sellingPrice,
          credit: 0,
          description: `Customer receivable for ${ticketData.customerName}`,
        },
        {
          accountId: revAccount.id,
          accountCode: revAccount.code,
          accountName: revAccount.name,
          debit: 0,
          credit: ticketData.sellingPrice,
          description: `Flight ticket sale (${ticketData.pnr})`,
        },
        {
          accountId: cosAccount.id,
          accountCode: cosAccount.code,
          accountName: cosAccount.name,
          debit: ticketData.netCost,
          credit: 0,
          description: `Net airline cost for ${ticketData.airlineName}`,
        },
        {
          accountId: apAccount.id,
          accountCode: apAccount.code,
          accountName: apAccount.name,
          debit: 0,
          credit: ticketData.netCost,
          description: `BSP clearing payable (${ticketData.airlineCode})`,
        },
      ],
    };

    const { entry, updatedAccounts } = postingEngine.post(journalInput, accounts);

    const newTicket: FlightTicket = {
      ...ticketData,
      id: ticketId,
      tenantId: currentTenant.id,
      status: 'ISSUED',
      journalEntryId: entry.id,
      createdAt: new Date().toISOString(),
    };

    setFlightTickets(prev => [newTicket, ...prev]);
    setJournalEntries(prev => [entry, ...prev]);
    setAccounts(updatedAccounts);

    recordAuditLog(
      'FLIGHT_TICKET_ISSUED',
      'FlightTicket',
      ticketId,
      `Issued ticket ${newTicket.ticketNumber} (PNR: ${newTicket.pnr}) on ${newTicket.airlineName}. Balanced JV ${entry.entryNumber} posted automatically.`
    );

    return { ticket: newTicket, journalEntry: entry };
  };

  const createManualJournalEntry = (
    input: Omit<PostJournalInput, 'tenantId' | 'currency' | 'userId'>
  ): JournalEntry => {
    if (!currentTenant) {
      throw new Error('Cannot create journal entry outside of tenant context.');
    }

    const { entry, updatedAccounts } = postingEngine.post(
      {
        ...input,
        tenantId: currentTenant.id,
        currency: currentTenant.currency,
        userId: `accountant@${currentTenant.slug}.com`,
      },
      accounts
    );

    setJournalEntries(prev => [entry, ...prev]);
    setAccounts(updatedAccounts);

    recordAuditLog(
      'JOURNAL_ENTRY_POSTED',
      'JournalEntry',
      entry.id,
      `Posted manual JV ${entry.entryNumber}: "${entry.memo}" with ${entry.lines.length} lines.`
    );

    return entry;
  };

  const addCustomer = (customerData: Omit<Customer, 'id' | 'createdAt' | 'tenantId'>): Customer => {
    if (!currentTenant) throw new Error('Tenant context required.');
    const newCustomer: Customer = {
      ...customerData,
      id: `cust-${Date.now()}`,
      tenantId: currentTenant.id,
      createdAt: new Date().toISOString(),
    };
    setCustomers(prev => [newCustomer, ...prev]);
    recordAuditLog('CUSTOMER_CREATED', 'Customer', newCustomer.id, `Created traveler profile for ${newCustomer.firstName} ${newCustomer.lastName}`);
    return newCustomer;
  };

  const addUmrahPackage = (pkgData: Omit<UmrahPackage, 'id' | 'tenantId'>): UmrahPackage => {
    if (!currentTenant) throw new Error('Tenant context required.');
    const newPkg: UmrahPackage = {
      ...pkgData,
      id: `umr-${Date.now()}`,
      tenantId: currentTenant.id,
    };
    setUmrahPackages(prev => [newPkg, ...prev]);
    recordAuditLog('UMRAH_PACKAGE_CREATED', 'UmrahPackage', newPkg.id, `Created batch ${newPkg.batchCode} (${newPkg.title})`);
    return newPkg;
  };

  const updateUmrahPackageStatus = (id: string, status: UmrahPackage['status']) => {
    setUmrahPackages(prev =>
      prev.map(p => (p.id === id ? { ...p, status } : p))
    );
    recordAuditLog('UMRAH_STATUS_CHANGED', 'UmrahPackage', id, `Updated batch status to ${status}`);
  };

  const addVisaApplication = (appData: Omit<VisaApplication, 'id' | 'tenantId' | 'submissionDate'>): VisaApplication => {
    if (!currentTenant) throw new Error('Tenant context required.');
    const newApp: VisaApplication = {
      ...appData,
      id: `visa-${Date.now()}`,
      tenantId: currentTenant.id,
      submissionDate: new Date().toISOString().split('T')[0],
    };
    setVisaApplications(prev => [newApp, ...prev]);
    recordAuditLog('VISA_APPLICATION_FILED', 'VisaApplication', newApp.id, `Filed ${newApp.visaType} for ${newApp.customerName}`);
    return newApp;
  };

  const updateVisaStatus = (id: string, status: VisaApplication['status']) => {
    setVisaApplications(prev =>
      prev.map(v => (v.id === id ? { ...v, status } : v))
    );
    recordAuditLog('VISA_STATUS_CHANGED', 'VisaApplication', id, `Updated visa application status to ${status}`);
  };

  // Filtered views adhering to RLS:
  // When in Platform Super Admin mode, super admin can inspect cross-tenant statistics
  // When inside a specific tenant, RLS guarantees only that tenant's records are provided
  const tenantFilteredAccounts = isSuperAdmin ? accounts : accounts.filter(a => a.tenantId === currentTenant?.id);
  const tenantFilteredEntries = isSuperAdmin ? journalEntries : journalEntries.filter(j => j.tenantId === currentTenant?.id);
  const tenantFilteredCustomers = isSuperAdmin ? customers : customers.filter(c => c.tenantId === currentTenant?.id);
  const tenantFilteredTickets = isSuperAdmin ? flightTickets : flightTickets.filter(t => t.tenantId === currentTenant?.id);
  const tenantFilteredPackages = isSuperAdmin ? umrahPackages : umrahPackages.filter(p => p.tenantId === currentTenant?.id);
  const tenantFilteredVisas = isSuperAdmin ? visaApplications : visaApplications.filter(v => v.tenantId === currentTenant?.id);
  const tenantFilteredAuditLogs = isSuperAdmin ? auditLogs : auditLogs.filter(l => l.tenantId === currentTenant?.id);

  return (
    <TenantContext.Provider
      value={{
        tenants,
        currentTenant,
        isSuperAdmin,
        activeDomain,
        simulatedEdgeHeaders,
        switchTenant,
        isDarkMode,
        toggleTheme,
        updateTenantStatus,
        updateTenantBranding,
        accounts: tenantFilteredAccounts,
        journalEntries: tenantFilteredEntries,
        customers: tenantFilteredCustomers,
        flightTickets: tenantFilteredTickets,
        umrahPackages: tenantFilteredPackages,
        visaApplications: tenantFilteredVisas,
        auditLogs: tenantFilteredAuditLogs,
        issueFlightTicket,
        createManualJournalEntry,
        addCustomer,
        addUmrahPackage,
        updateUmrahPackageStatus,
        addVisaApplication,
        updateVisaStatus,
        recordAuditLog,
      }}
    >
      {children}
    </TenantContext.Provider>
  );
};

export const useTenant = () => {
  const context = useContext(TenantContext);
  if (!context) {
    throw new Error('useTenant must be used within a TenantProvider');
  }
  return context;
};

import { JournalEntry, JournalLine, Account } from '../../types';

export interface PostLineInput {
  accountId: string;
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  description?: string;
}

export interface PostJournalInput {
  tenantId: string;
  currency: string;
  userId: string;
  entryDate: string;
  memo: string;
  referenceType?: 'FLIGHT_TICKET' | 'UMRAH_PACKAGE' | 'VISA_APPLICATION' | 'MANUAL' | 'BANK_RECON';
  referenceId?: string;
  lines: PostLineInput[];
}

export class PostingEngine {
  private entrySequenceMap: Map<string, number> = new Map();

  /**
   * Posts a balanced double-entry journal entry according to strict IFRS / GAAP constraints.
   */
  public post(input: PostJournalInput, accounts: Account[]): { entry: JournalEntry; updatedAccounts: Account[] } {
    if (!input.lines || input.lines.length < 2) {
      throw new Error('Double-entry transaction requires at least two distinct lines.');
    }

    let totalDebit = 0;
    let totalCredit = 0;

    for (const line of input.lines) {
      if (line.debit < 0 || line.credit < 0) {
        throw new Error('Journal line debit and credit amounts must be non-negative.');
      }
      if (line.debit > 0 && line.credit > 0) {
        throw new Error('A journal line cannot contain both debit and credit.');
      }
      if (line.debit === 0 && line.credit === 0) {
        throw new Error('Journal line must have a non-zero debit or credit.');
      }

      totalDebit += line.debit;
      totalCredit += line.credit;
    }

    // Precise 4-decimal balance check (comparable to bccomp in Laravel)
    const diff = Math.abs(totalDebit - totalCredit);
    if (diff > 0.0001) {
      throw new Error(
        `Unbalanced Entry: Debit total (${totalDebit.toFixed(2)}) does not equal Credit total (${totalCredit.toFixed(2)}). Delta: ${diff.toFixed(4)}`
      );
    }

    // Verify all account IDs exist
    const accountMap = new Map<string, Account>();
    accounts.forEach(a => accountMap.set(a.id, a));

    for (const line of input.lines) {
      if (!accountMap.has(line.accountId)) {
        throw new Error(`Referenced account ID [${line.accountId}] does not exist for this tenant.`);
      }
    }

    const year = new Date(input.entryDate).getFullYear() || new Date().getFullYear();
    const seqKey = `${input.tenantId}_${year}`;
    const nextCount = (this.entrySequenceMap.get(seqKey) || 0) + 1;
    this.entrySequenceMap.set(seqKey, nextCount);

    const entryNumber = `JV-${year}-${String(nextCount).padStart(6, '0')}`;
    const entryId = `je_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;

    const journalLines: JournalLine[] = input.lines.map((l, idx) => ({
      id: `jl_${entryId}_${idx + 1}`,
      tenantId: input.tenantId,
      journalEntryId: entryId,
      accountId: l.accountId,
      accountCode: l.accountCode,
      accountName: l.accountName,
      debit: l.debit,
      credit: l.credit,
      currency: input.currency,
      exchangeRate: 1.0,
      baseDebit: l.debit,
      baseCredit: l.credit,
      description: l.description,
    }));

    const entry: JournalEntry = {
      id: entryId,
      tenantId: input.tenantId,
      entryNumber,
      entryDate: input.entryDate,
      status: 'POSTED',
      referenceType: input.referenceType,
      referenceId: input.referenceId,
      memo: input.memo,
      postedAt: new Date().toISOString(),
      postedBy: input.userId,
      lines: journalLines,
      createdAt: new Date().toISOString(),
    };

    // Update account balances based on AccountType normal balance rules:
    // ASSET & EXPENSE: Debit increases (+), Credit decreases (-)
    // LIABILITY, EQUITY & REVENUE: Credit increases (+), Debit decreases (-)
    const updatedAccounts = accounts.map(account => {
      const lineForAccount = input.lines.filter(l => l.accountId === account.id);
      if (lineForAccount.length === 0) return account;

      let netDelta = 0;
      lineForAccount.forEach(l => {
        if (account.type === 'ASSET' || account.type === 'EXPENSE') {
          netDelta += (l.debit - l.credit);
        } else {
          netDelta += (l.credit - l.debit);
        }
      });

      return {
        ...account,
        currentBalance: Math.round((account.currentBalance + netDelta) * 100) / 100,
      };
    });

    return { entry, updatedAccounts };
  }

  public setSequence(tenantId: string, year: number, currentCount: number) {
    this.entrySequenceMap.set(`${tenantId}_${year}`, currentCount);
  }
}

export const postingEngine = new PostingEngine();

import { FlightOffer, GdsSource, FlightTicket } from '../../types';

export interface FlightSearchCriteria {
  origin: string;
  destination: string;
  departureDate: string;
  passengers: number;
  cabinClass?: 'ECONOMY' | 'BUSINESS' | 'FIRST';
}

export class GdsFlightAdapter {
  private static readonly SAMPLE_ROUTES: Record<string, FlightOffer[]> = {
    'DAC-JED': [
      {
        id: 'offer-sv-801',
        airlineCode: 'SV',
        airlineName: 'Saudia',
        flightNumber: 'SV-801',
        origin: 'DAC',
        destination: 'JED',
        departureTime: '04:15',
        arrivalTime: '08:45',
        duration: '7h 30m',
        stops: 0,
        baseFare: 68000,
        taxes: 12500,
        netCost: 75500,
        recommendedSellingPrice: 84000,
        availableSeats: 9,
        gdsSource: 'AMADEUS',
      },
      {
        id: 'offer-bg-035',
        airlineCode: 'BG',
        airlineName: 'Biman Bangladesh Airlines',
        flightNumber: 'BG-035',
        origin: 'DAC',
        destination: 'JED',
        departureTime: '20:30',
        arrivalTime: '01:15 (+1)',
        duration: '7h 45m',
        stops: 0,
        baseFare: 62000,
        taxes: 11200,
        netCost: 68800,
        recommendedSellingPrice: 76000,
        availableSeats: 14,
        gdsSource: 'AMADEUS',
      },
      {
        id: 'offer-ek-585',
        airlineCode: 'EK',
        airlineName: 'Emirates',
        flightNumber: 'EK-585 / EK-803',
        origin: 'DAC',
        destination: 'JED',
        departureTime: '01:40',
        arrivalTime: '09:55',
        duration: '11h 15m',
        stops: 1,
        baseFare: 74000,
        taxes: 14200,
        netCost: 82000,
        recommendedSellingPrice: 91500,
        availableSeats: 6,
        gdsSource: 'SABRE',
      },
    ],
    'DAC-DXB': [
      {
        id: 'offer-ek-583',
        airlineCode: 'EK',
        airlineName: 'Emirates',
        flightNumber: 'EK-583',
        origin: 'DAC',
        destination: 'DXB',
        departureTime: '10:15',
        arrivalTime: '13:55',
        duration: '4h 40m',
        stops: 0,
        baseFare: 48000,
        taxes: 8400,
        netCost: 52400,
        recommendedSellingPrice: 59000,
        availableSeats: 12,
        gdsSource: 'AMADEUS',
      },
      {
        id: 'offer-bg-047',
        airlineCode: 'BG',
        airlineName: 'Biman Bangladesh Airlines',
        flightNumber: 'BG-047',
        origin: 'DAC',
        destination: 'DXB',
        departureTime: '19:45',
        arrivalTime: '23:30',
        duration: '4h 45m',
        stops: 0,
        baseFare: 42000,
        taxes: 7800,
        netCost: 46200,
        recommendedSellingPrice: 52500,
        availableSeats: 18,
        gdsSource: 'AMADEUS',
      },
      {
        id: 'offer-fz-584',
        airlineCode: 'FZ',
        airlineName: 'Flydubai',
        flightNumber: 'FZ-584',
        origin: 'DAC',
        destination: 'DXB',
        departureTime: '15:20',
        arrivalTime: '19:10',
        duration: '4h 50m',
        stops: 0,
        baseFare: 39000,
        taxes: 7100,
        netCost: 43100,
        recommendedSellingPrice: 48500,
        availableSeats: 22,
        gdsSource: 'SABRE',
      },
    ],
    'DAC-LHR': [
      {
        id: 'offer-bg-201',
        airlineCode: 'BG',
        airlineName: 'Biman Bangladesh (Sylhet Direct)',
        flightNumber: 'BG-201',
        origin: 'DAC',
        destination: 'LHR',
        departureTime: '11:30',
        arrivalTime: '17:15',
        duration: '10h 45m',
        stops: 0,
        baseFare: 88000,
        taxes: 18900,
        netCost: 99400,
        recommendedSellingPrice: 112000,
        availableSeats: 5,
        gdsSource: 'AMADEUS',
      },
      {
        id: 'offer-qr-641',
        airlineCode: 'QR',
        airlineName: 'Qatar Airways',
        flightNumber: 'QR-641 / QR-001',
        origin: 'DAC',
        destination: 'LHR',
        departureTime: '03:15',
        arrivalTime: '13:40',
        duration: '14h 25m',
        stops: 1,
        baseFare: 92000,
        taxes: 21500,
        netCost: 104500,
        recommendedSellingPrice: 118000,
        availableSeats: 8,
        gdsSource: 'SABRE',
      },
    ],
  };

  public static searchFlights(criteria: FlightSearchCriteria): FlightOffer[] {
    const key = `${criteria.origin.toUpperCase()}-${criteria.destination.toUpperCase()}`;
    const directOffers = this.SAMPLE_ROUTES[key];

    if (directOffers && directOffers.length > 0) {
      return directOffers;
    }

    // Dynamic fallback offer for any city pair
    return [
      {
        id: `offer-dyn-${Date.now()}-1`,
        airlineCode: 'BG',
        airlineName: 'Biman Bangladesh Airlines',
        flightNumber: 'BG-882',
        origin: criteria.origin.toUpperCase(),
        destination: criteria.destination.toUpperCase(),
        departureTime: '09:00',
        arrivalTime: '14:30',
        duration: '5h 30m',
        stops: 0,
        baseFare: 45000,
        taxes: 8500,
        netCost: 49500,
        recommendedSellingPrice: 56000,
        availableSeats: 15,
        gdsSource: 'AMADEUS',
      },
      {
        id: `offer-dyn-${Date.now()}-2`,
        airlineCode: 'EK',
        airlineName: 'Emirates Global Hub',
        flightNumber: 'EK-914',
        origin: criteria.origin.toUpperCase(),
        destination: criteria.destination.toUpperCase(),
        departureTime: '18:15',
        arrivalTime: '00:45 (+1)',
        duration: '6h 30m',
        stops: 1,
        baseFare: 52000,
        taxes: 9800,
        netCost: 56800,
        recommendedSellingPrice: 64500,
        availableSeats: 8,
        gdsSource: 'SABRE',
      },
    ];
  }

  public static generatePnr(): string {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let res = '';
    for (let i = 0; i < 6; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return res;
  }

  public static generateTicketNumber(airlineCode: string): string {
    const prefixMap: Record<string, string> = {
      BG: '098',
      SV: '065',
      EK: '176',
      QR: '157',
      FZ: '141',
    };
    const prefix = prefixMap[airlineCode] || '999';
    const digits = Math.floor(1000000000 + Math.random() * 9000000000);
    return `${prefix}-${digits}`;
  }

  public static calculatePricing(baseFare: number, taxes: number, commissionPercent: number = 7) {
    const commissionEarned = Math.round(baseFare * (commissionPercent / 100));
    // AIT (Advance Income Tax) 0.3% on Gross Base Fare per Bangladesh tax code
    const aitTax = Math.round(baseFare * 0.003);
    const netCost = baseFare + taxes - commissionEarned + aitTax;
    const standardMarkup = Math.round(commissionEarned * 0.6);
    const sellingPrice = netCost + standardMarkup;

    return {
      baseFare,
      taxes,
      commissionEarned,
      aitTax,
      netCost,
      sellingPrice,
      netProfitMargin: sellingPrice - netCost,
    };
  }
}

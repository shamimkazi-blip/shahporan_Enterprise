import test from 'node:test';
import assert from 'node:assert/strict';
import { PostingEngine } from './accounting/postingEngine';
import { SafeHttpClient } from './security/safeHttpClient';
import { PostgresRlsEngine } from './security/rlsSimulator';
import { Account } from '../types';

test('PostingEngine correctly posts balanced double-entry transaction and increments sequence', () => {
  const engine = new PostingEngine();
  const mockAccounts: Account[] = [
    {
      id: 'acc-1',
      tenantId: 't1',
      code: '1010',
      name: 'Cash in Hand',
      type: 'ASSET',
      isReconcilable: true,
      isActive: true,
      currentBalance: 50000,
    },
    {
      id: 'acc-2',
      tenantId: 't1',
      code: '4010',
      name: 'Flight Ticket Revenue',
      type: 'REVENUE',
      isReconcilable: false,
      isActive: true,
      currentBalance: 120000,
    },
  ];

  const result = engine.post(
    {
      tenantId: 't1',
      currency: 'BDT',
      userId: 'usr-admin',
      entryDate: '2026-10-31',
      memo: 'Cash ticket sale BG-047',
      lines: [
        {
          accountId: 'acc-1',
          accountCode: '1010',
          accountName: 'Cash in Hand',
          debit: 25000,
          credit: 0,
        },
        {
          accountId: 'acc-2',
          accountCode: '4010',
          accountName: 'Flight Ticket Revenue',
          debit: 0,
          credit: 25000,
        },
      ],
    },
    mockAccounts
  );

  assert.equal(result.entry.entryNumber, 'JV-2026-000001');
  assert.equal(result.entry.status, 'POSTED');
  assert.equal(result.entry.lines.length, 2);

  // Asset debit should increase balance: 50000 + 25000 = 75000
  const updatedCash = result.updatedAccounts.find(a => a.id === 'acc-1');
  assert.equal(updatedCash?.currentBalance, 75000);

  // Revenue credit should increase balance: 120000 + 25000 = 145000
  const updatedRev = result.updatedAccounts.find(a => a.id === 'acc-2');
  assert.equal(updatedRev?.currentBalance, 145000);
});

test('PostingEngine rejects unbalanced entries', () => {
  const engine = new PostingEngine();
  const mockAccounts: Account[] = [
    {
      id: 'acc-1',
      tenantId: 't1',
      code: '1010',
      name: 'Cash in Hand',
      type: 'ASSET',
      isReconcilable: true,
      isActive: true,
      currentBalance: 0,
    },
    {
      id: 'acc-2',
      tenantId: 't1',
      code: '4010',
      name: 'Flight Ticket Revenue',
      type: 'REVENUE',
      isReconcilable: false,
      isActive: true,
      currentBalance: 0,
    },
  ];

  assert.throws(
    () => {
      engine.post(
        {
          tenantId: 't1',
          currency: 'BDT',
          userId: 'usr-admin',
          entryDate: '2026-10-31',
          memo: 'Unbalanced test',
          lines: [
            { accountId: 'acc-1', accountCode: '1010', accountName: 'Cash', debit: 1000, credit: 0 },
            { accountId: 'acc-2', accountCode: '4010', accountName: 'Rev', debit: 0, credit: 950 },
          ],
        },
        mockAccounts
      );
    },
    { message: /Unbalanced Entry/ }
  );
});

test('SafeHttpClient blocks internal SSRF IP ranges', () => {
  // AWS/Cloud metadata service
  const resMeta = SafeHttpClient.validateUrl('http://169.254.169.254/latest/meta-data/');
  assert.equal(resMeta.isSafe, false);
  assert.equal(resMeta.blockedCidr, '169.254.0.0/16');

  // Localhost
  const resLocal = SafeHttpClient.validateUrl('http://127.0.0.1:8000/internal');
  assert.equal(resLocal.isSafe, false);
  assert.equal(resLocal.blockedCidr, '127.0.0.0/8');

  // Private RFC 1918 Class A
  const resPrivate = SafeHttpClient.validateUrl('http://10.0.0.5/admin');
  assert.equal(resPrivate.isSafe, false);
  assert.equal(resPrivate.blockedCidr, '10.0.0.0/8');

  // Valid external GDS host
  const resGds = SafeHttpClient.validateUrl('https://api.amadeus.com/v2/shopping/flight-offers');
  assert.equal(resGds.isSafe, true);
});

test('PostgresRlsEngine achieves 0% isolation leakage across tenants', () => {
  const rls = new PostgresRlsEngine();
  const testResults = rls.runAutomatedLeakTestSuite();

  assert.equal(testResults.length, 4);
  for (const t of testResults) {
    assert.equal(t.passed, true, `Test failed: ${t.testName}`);
    assert.equal(t.isolationLeakDetected, false, `Isolation leak detected in ${t.testName}`);
  }
});

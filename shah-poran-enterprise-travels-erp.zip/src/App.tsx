/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TenantProvider, useTenant } from './context/TenantContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { OverviewView } from './components/dashboard/OverviewView';
import { FlightTicketingView } from './components/flights/FlightTicketingView';
import { FlightBookingModal } from './components/flights/FlightBookingModal';
import { UmrahPackagesView } from './components/umrah/UmrahPackagesView';
import { VisaVaultView } from './components/visa/VisaVaultView';
import { AccountingView } from './components/accounting/AccountingView';
import { SecuritySandboxView } from './components/security/SecuritySandboxView';
import { WhiteLabelCustomizer } from './components/whitelabel/WhiteLabelCustomizer';
import { SuperAdminView } from './components/admin/SuperAdminView';
import { AICopilotModal } from './components/ai/AICopilotModal';
import { FloatingAIButton } from './components/ai/FloatingAIButton';

const MainAppContent: React.FC = () => {
  const [currentView, setCurrentView] = useState<string>('overview');
  const [isIssueModalOpen, setIsIssueModalOpen] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const { isSuperAdmin } = useTenant();

  // Global keyboard shortcut: Cmd+K / Ctrl+K opens AI Copilot
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsAIModalOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans selection:bg-blue-600 selection:text-white transition-colors duration-150">
      {/* Top Header & Context Bar with AI Button */}
      <Header
        currentView={currentView}
        onNavigate={setCurrentView}
        onOpenIssueModal={() => setIsIssueModalOpen(true)}
        onOpenAIModal={() => setIsAIModalOpen(true)}
      />

      {/* Main Workspace: Sidebar + Content */}
      <div className="flex-1 flex overflow-hidden">
        <Sidebar
          currentView={currentView}
          onNavigate={setCurrentView}
          onOpenAIModal={() => setIsAIModalOpen(true)}
        />

        <main className="flex-1 overflow-y-auto p-6 lg:p-8 bg-slate-100/70 dark:bg-slate-950 transition-colors duration-150">
          <div className="max-w-7xl mx-auto">
            {currentView === 'overview' && (
              <OverviewView
                onNavigate={setCurrentView}
                onOpenIssueModal={() => setIsIssueModalOpen(true)}
                onOpenAIModal={() => setIsAIModalOpen(true)}
              />
            )}

            {currentView === 'flights' && (
              <FlightTicketingView
                onOpenIssueModal={() => setIsIssueModalOpen(true)}
                onNavigateToAccounting={() => setCurrentView('accounting')}
              />
            )}

            {currentView === 'umrah' && <UmrahPackagesView />}

            {currentView === 'visa' && <VisaVaultView />}

            {currentView === 'accounting' && <AccountingView />}

            {currentView === 'security' && <SecuritySandboxView />}

            {currentView === 'whitelabel' && <WhiteLabelCustomizer />}

            {currentView === 'superadmin' && <SuperAdminView />}
          </div>
        </main>
      </div>

      {/* Global Modals */}
      <FlightBookingModal
        isOpen={isIssueModalOpen}
        onClose={() => setIsIssueModalOpen(false)}
      />

      {/* Shah Poran AI Copilot Modal */}
      <AICopilotModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
      />

      {/* Floating AI Button (Quick access from any page) */}
      <FloatingAIButton onClick={() => setIsAIModalOpen(true)} />
    </div>
  );
};

export default function App() {
  return (
    <TenantProvider>
      <MainAppContent />
    </TenantProvider>
  );
}

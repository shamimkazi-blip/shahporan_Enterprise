export type TenantStatus = 
  | 'PENDING_APPROVAL' 
  | 'UNDER_REVIEW' 
  | 'ACTIVE' 
  | 'SUSPENDED' 
  | 'REJECTED' 
  | 'ARCHIVED';

export interface TenantBranding {
  companyName: string;
  legalName?: string;
  logoLightUrl?: string;
  logoDarkUrl?: string;
  faviconUrl?: string;
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  invoiceHeaderHtml?: string;
  invoiceFooterHtml?: string;
  contactEmail?: string;
  contactPhone?: string;
  officeAddress?: string;
}

export interface Tenant {
  id: string;
  name: string;
  slug: string;
  customDomain?: string;
  customDomainVerifiedAt?: string | null;
  status: TenantStatus;
  rejectionReason?: string;
  currency: string;
  timezone: string;
  createdAt: string;
  updatedAt: string;
  branding: TenantBranding;
}

export type AccountType = 'ASSET' | 'LIABILITY' | 'EQUITY' | 'REVENUE' | 'EXPENSE';

export interface Account {
  id: string;
  tenantId: string;
  code: string;
  name: string;
  type: AccountType;
  parentId?: string;
  isReconcilable: boolean;
  isActive: boolean;
  currentBalance: number; // Positive for normal balance (Debit for Assets/Expenses, Credit for Liab/Equity/Rev)
}

export type JournalStatus = 'DRAFT' | 'POSTED' | 'VOIDED';

export interface JournalLine {
  id: string;
  tenantId: string;
  journalEntryId: string;
  accountId: string;
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  currency: string;
  exchangeRate: number;
  baseDebit: number;
  baseCredit: number;
  description?: string;
}

export interface JournalEntry {
  id: string;
  tenantId: string;
  entryNumber: string;
  entryDate: string;
  status: JournalStatus;
  referenceType?: 'FLIGHT_TICKET' | 'UMRAH_PACKAGE' | 'VISA_APPLICATION' | 'MANUAL' | 'BANK_RECON';
  referenceId?: string;
  memo: string;
  postedAt?: string;
  postedBy: string;
  lines: JournalLine[];
  createdAt: string;
}

export interface Customer {
  id: string;
  tenantId: string;
  firstName: string;
  lastName: string;
  email?: string;
  phone: string;
  passportNumber?: string;
  passportExpiry?: string;
  nationality?: string;
  dateOfBirth?: string;
  createdAt: string;
}

export type TicketStatus = 'CONFIRMED' | 'ISSUED' | 'REISSUED' | 'VOID' | 'REFUNDED';
export type GdsSource = 'AMADEUS' | 'SABRE' | 'TRAVELPORT' | 'DIRECT';

export interface FlightTicket {
  id: string;
  tenantId: string;
  customerId: string;
  customerName: string;
  pnr: string;
  ticketNumber: string;
  airlineCode: string; // e.g. BG, EK, SV, QR
  airlineName: string;
  route: string; // e.g. DAC-DXB, DAC-JED
  departureDate: string;
  returnDate?: string;
  flightNumber: string;
  cabinClass: 'ECONOMY' | 'BUSINESS' | 'FIRST';
  gdsSource: GdsSource;
  baseFare: number;
  taxes: number;
  commissionEarned: number;
  aitTax: number; // Advance Income Tax (e.g. 0.3% in Bangladesh IATA regulations)
  netCost: number;
  sellingPrice: number;
  status: TicketStatus;
  journalEntryId?: string;
  createdAt: string;
}

export type PackageStatus = 'PLANNING' | 'OPEN_FOR_BOOKING' | 'VISA_PROCESSING' | 'CONFIRMED' | 'DEPARTED' | 'COMPLETED';

export interface UmrahPackage {
  id: string;
  tenantId: string;
  batchCode: string;
  title: string;
  season: 'RAMADAN' | 'REGULAR' | 'SHAWWAL' | 'HAJJ';
  departureDate: string;
  returnDate: string;
  durationDays: number;
  makkahHotel: string;
  makkahHotelStars: number;
  madinahHotel: string;
  madinahHotelStars: number;
  capacity: number;
  enrolledPilgrims: number;
  pricePerPerson: number;
  status: PackageStatus;
  includedServices: string[];
}

export type VisaStatus = 'DRAFT' | 'DOCUMENTS_VERIFIED' | 'SUBMITTED_TO_EMBASSY' | 'BIOMETRICS_SCHEDULED' | 'ISSUED' | 'REJECTED';

export interface VisaApplication {
  id: string;
  tenantId: string;
  customerId: string;
  customerName: string;
  country: string;
  visaType: string;
  passportNumber: string;
  passportExpiry: string;
  status: VisaStatus;
  submissionDate: string;
  feeAmount: number;
  documentCount: number;
  lastPresignedUrlRequested?: string;
  notes?: string;
}

export interface AuditLog {
  id: string;
  tenantId: string;
  actorEmail: string;
  action: string;
  entityType: string;
  entityId: string;
  timestamp: string;
  clientIp: string;
  details: string;
}

export interface FlightOffer {
  id: string;
  airlineCode: string;
  airlineName: string;
  flightNumber: string;
  origin: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  stops: number;
  baseFare: number;
  taxes: number;
  netCost: number;
  recommendedSellingPrice: number;
  availableSeats: number;
  gdsSource: GdsSource;
}

import React, { useState, useEffect } from 'react';
import { useTenant } from '../../context/TenantContext';
import { VisaApplication, VisaStatus } from '../../types';
import { 
  FileCheck2, 
  Lock, 
  Clock, 
  ScanLine, 
  Eye, 
  CheckCircle2
} from 'lucide-react';

export const VisaVaultView: React.FC = () => {
  const { currentTenant, visaApplications, updateVisaStatus, recordAuditLog } = useTenant();
  const currency = currentTenant?.currency || 'BDT';

  const [activePresignedUrl, setActivePresignedUrl] = useState<{
    visaId: string;
    url: string;
    expiresInSeconds: number;
    fileName: string;
  } | null>(null);

  const [isOCRModalOpen, setIsOCRModalOpen] = useState(false);
  const [ocrScanning, setOcrScanning] = useState(false);
  const [ocrData, setOcrData] = useState<{
    passportNo: string;
    surname: string;
    givenNames: string;
    nationality: string;
    dob: string;
    expiryDate: string;
  } | null>(null);

  // Countdown timer for 5-minute presigned URL
  useEffect(() => {
    if (!activePresignedUrl) return;

    const timer = setInterval(() => {
      setActivePresignedUrl(prev => {
        if (!prev) return null;
        if (prev.expiresInSeconds <= 1) {
          return null; // Expired!
        }
        return {
          ...prev,
          expiresInSeconds: prev.expiresInSeconds - 1,
        };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [activePresignedUrl]);

  const handleGeneratePresignedUrl = (app: VisaApplication) => {
    const filename = `passport_${app.passportNumber}_scan.pdf`;
    const token = Math.random().toString(36).substring(2, 15);
    const presignedUrl = `https://s3.ap-southeast-1.amazonaws.com/shahporan-vault-private/${currentTenant?.slug}/${filename}?X-Amz-Security-Token=${token}&X-Amz-Expires=300`;

    setActivePresignedUrl({
      visaId: app.id,
      url: presignedUrl,
      expiresInSeconds: 300, // 5 minutes (300 seconds)
      fileName: filename,
    });

    recordAuditLog(
      'PRESIGNED_S3_ACCESS_GRANTED',
      'VisaApplication',
      app.id,
      `Generated 5-minute presigned URL for [${filename}] for authorized officer`
    );
  };

  const handleSimulatePassportOcr = () => {
    setOcrScanning(true);
    setOcrData(null);

    setTimeout(() => {
      setOcrScanning(false);
      setOcrData({
        passportNo: 'A' + Math.floor(10000000 + Math.random() * 90000000),
        surname: 'CHOWDHURY',
        givenNames: 'KAMRUL HASAN',
        nationality: 'BGD',
        dob: '1987-11-04',
        expiryDate: '2032-10-14',
      });
    }, 1200);
  };

  const getStatusBadge = (status: VisaStatus) => {
    switch (status) {
      case 'DRAFT':
        return 'text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700';
      case 'DOCUMENTS_VERIFIED':
        return 'text-blue-600 dark:text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'SUBMITTED_TO_EMBASSY':
        return 'text-amber-600 dark:text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'BIOMETRICS_SCHEDULED':
        return 'text-purple-600 dark:text-purple-400 bg-purple-500/10 border-purple-500/20';
      case 'ISSUED':
        return 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'REJECTED':
        return 'text-rose-600 dark:text-rose-400 bg-rose-500/10 border-rose-500/20';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm transition-colors">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Visa Document Vault & Compliance</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 font-semibold">
              S3 PRIVATE ENCRYPTED
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Zero-knowledge document storage: Passports and visas accessible only via ephemeral ≤5 min presigned URLs.
          </p>
        </div>

        <button
          onClick={() => setIsOCRModalOpen(true)}
          className="px-4 py-2 text-xs font-semibold text-white rounded-lg shadow-sm flex items-center gap-1.5 transition-all shrink-0 bg-blue-600 hover:bg-blue-500"
        >
          <ScanLine className="w-3.5 h-3.5" />
          <span>Launch Passport OCR Scanner</span>
        </button>
      </div>

      {/* Active Ephemeral Presigned URL Banner */}
      {activePresignedUrl && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-400 flex items-center justify-center shrink-0">
              <Clock className="w-4 h-4 animate-pulse" />
            </div>
            <div>
              <div className="font-semibold text-amber-800 dark:text-amber-300 flex items-center gap-2">
                <span>Active Ephemeral Presigned S3 Access Token</span>
                <span className="font-mono bg-amber-500/20 text-amber-700 dark:text-amber-300 px-1.5 py-0.5 rounded text-[11px]">
                  {Math.floor(activePresignedUrl.expiresInSeconds / 60)}:
                  {String(activePresignedUrl.expiresInSeconds % 60).padStart(2, '0')} remaining
                </span>
              </div>
              <div className="font-mono text-slate-600 dark:text-slate-400 text-[11px] truncate max-w-xl mt-0.5">
                {activePresignedUrl.fileName} · Token cryptographically signed
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={() => alert(`Simulated secure document view: ${activePresignedUrl.fileName}\nAuthenticated via presigned S3 token.`)}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition-colors flex items-center gap-1"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>Inspect Secure Document</span>
            </button>
            <button
              onClick={() => setActivePresignedUrl(null)}
              className="px-2.5 py-1.5 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"
            >
              Revoke
            </button>
          </div>
        </div>
      )}

      {/* Visa Applications Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm transition-colors">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Active Visa Applications ({visaApplications.length})</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">Embassy submission pipeline & document checklist</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase text-[11px] font-sans">
              <tr>
                <th className="py-3 px-4">Traveler / Applicant</th>
                <th className="py-3 px-4">Country & Visa Category</th>
                <th className="py-3 px-4">Passport Number</th>
                <th className="py-3 px-4">Docs</th>
                <th className="py-3 px-4 text-right">Govt / Service Fee</th>
                <th className="py-3 px-4 text-center">Pipeline Status</th>
                <th className="py-3 px-4 text-center">Security Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {visaApplications.map(app => (
                <tr key={app.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3 px-4 font-sans">
                    <div className="font-semibold text-slate-900 dark:text-white">{app.customerName}</div>
                    <div className="text-[11px] text-slate-500 font-mono">Applied: {app.submissionDate}</div>
                  </td>

                  <td className="py-3 px-4 font-sans">
                    <div className="font-medium text-slate-800 dark:text-slate-200">{app.country}</div>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">{app.visaType}</div>
                  </td>

                  <td className="py-3 px-4">
                    <span className="font-bold text-amber-600 dark:text-amber-400">{app.passportNumber}</span>
                    <div className="text-[10px] text-slate-500">Exp: {app.passportExpiry}</div>
                  </td>

                  <td className="py-3 px-4">
                    <span className="text-slate-700 dark:text-slate-300 font-semibold">{app.documentCount} files</span>
                    <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-sans">S3 Encrypted</div>
                  </td>

                  <td className="py-3 px-4 text-right">
                    <span className="text-slate-900 dark:text-white font-bold">{app.feeAmount.toLocaleString()}</span>{' '}
                    <span className="text-[10px] text-slate-500 font-sans">{currency}</span>
                  </td>

                  <td className="py-3 px-4 text-center">
                    <select
                      value={app.status}
                      onChange={e => updateVisaStatus(app.id, e.target.value as VisaStatus)}
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border ${getStatusBadge(app.status)} bg-slate-50 dark:bg-slate-950 focus:outline-none`}
                    >
                      <option value="DRAFT">DRAFT</option>
                      <option value="DOCUMENTS_VERIFIED">DOCS VERIFIED</option>
                      <option value="SUBMITTED_TO_EMBASSY">AT EMBASSY</option>
                      <option value="BIOMETRICS_SCHEDULED">BIOMETRICS</option>
                      <option value="ISSUED">ISSUED</option>
                      <option value="REJECTED">REJECTED</option>
                    </select>
                  </td>

                  <td className="py-3 px-4 text-center font-sans">
                    <button
                      onClick={() => handleGeneratePresignedUrl(app)}
                      className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-blue-600 dark:text-blue-400 border border-slate-200 dark:border-slate-700 rounded-md transition-colors inline-flex items-center gap-1.5"
                    >
                      <Lock className="w-3 h-3 text-amber-500 dark:text-amber-400" />
                      <span>Get S3 URL (5m)</span>
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Passport OCR Modal Simulator */}
      {isOCRModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-lg w-full p-6 shadow-2xl relative transition-colors">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div className="flex items-center gap-2">
                <ScanLine className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Machine-Readable Passport (MRP) OCR Worker</h3>
              </div>
              <button onClick={() => setIsOCRModalOpen(false)} className="text-slate-400 hover:text-slate-700 dark:hover:text-white">✕</button>
            </div>

            <div className="space-y-4 text-xs">
              <p className="text-slate-600 dark:text-slate-400">
                Simulates asynchronous worker extraction from ICAO 9303 machine-readable travel documents (MRZ 2-line optical scan).
              </p>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-center">
                <button
                  onClick={handleSimulatePassportOcr}
                  disabled={ocrScanning}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-300 dark:disabled:bg-slate-800 text-white font-semibold rounded-lg transition-colors inline-flex items-center gap-2"
                >
                  <ScanLine className="w-4 h-4" />
                  <span>{ocrScanning ? 'Parsing ICAO MRZ Lines...' : 'Scan Sample Passport Document'}</span>
                </button>
              </div>

              {ocrData && (
                <div className="p-4 bg-slate-50 dark:bg-slate-950 border border-emerald-500/30 rounded-lg font-mono space-y-2">
                  <div className="text-emerald-600 dark:text-emerald-400 font-sans font-semibold text-xs flex items-center gap-1.5 mb-2">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>OCR Extraction Succeeded (Confidence: 99.4%)</span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-slate-700 dark:text-slate-300">
                    <div>
                      <span className="text-slate-500 block">Passport Number:</span>
                      <span className="text-slate-900 dark:text-white font-bold">{ocrData.passportNo}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Nationality:</span>
                      <span className="text-slate-900 dark:text-white">{ocrData.nationality}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Surname:</span>
                      <span className="text-slate-900 dark:text-white">{ocrData.surname}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Given Names:</span>
                      <span className="text-slate-900 dark:text-white">{ocrData.givenNames}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Date of Birth:</span>
                      <span className="text-slate-900 dark:text-white">{ocrData.dob}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Expiry Date:</span>
                      <span className="text-slate-900 dark:text-white">{ocrData.expiryDate}</span>
                    </div>
                  </div>
                </div>
              )}

              <div className="pt-2 flex justify-end">
                <button
                  onClick={() => setIsOCRModalOpen(false)}
                  className="px-4 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg transition-colors"
                >
                  Close Scanner
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

import React from 'react';
import { Sparkles, Bot } from 'lucide-react';

interface FloatingAIButtonProps {
  onClick: () => void;
}

export const FloatingAIButton: React.FC<FloatingAIButtonProps> = ({ onClick }) => {
  return (
    <div className="fixed bottom-6 right-6 z-40 flex items-center gap-2 group">
      <button
        onClick={onClick}
        aria-label="Open Shah Poran AI Copilot"
        title="Open AI Copilot (⌘K)"
        className="flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-500 hover:to-pink-500 text-white shadow-xl shadow-indigo-600/30 hover:shadow-indigo-600/50 hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer border border-white/20"
      >
        <div className="relative">
          <Sparkles className="w-4 h-4 animate-spin-slow" />
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-400" />
        </div>
        <span className="text-xs font-bold tracking-tight">AI Copilot</span>
        <span className="hidden md:inline-flex items-center text-[10px] bg-black/20 px-1.5 py-0.5 rounded-full font-mono text-indigo-100 border border-white/10">
          ⌘K
        </span>
      </button>
    </div>
  );
};

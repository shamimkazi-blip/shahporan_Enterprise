import React, { useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { Tenant } from '../../types';
import { 
  Check, 
  AlertCircle, 
  ArrowRight
} from 'lucide-react';

export const SuperAdminView: React.FC = () => {
  const { tenants, updateTenantStatus, switchTenant } = useTenant();

  const [selectedTenant, setSelectedTenant] = useState<Tenant | null>(null);
  const [rejectReason, setRejectReason] = useState('');
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);

  const pendingTenants = tenants.filter(t => t.status === 'PENDING_APPROVAL');

  const handleApprove = (tenant: Tenant) => {
    updateTenantStatus(tenant.id, 'ACTIVE');
  };

  const handleReject = () => {
    if (!selectedTenant) return;
    updateTenantStatus(selectedTenant.id, 'REJECTED', rejectReason || 'Documentation non-compliant');
    setIsRejectModalOpen(false);
    setSelectedTenant(null);
    setRejectReason('');
  };

  const handleSuspend = (tenant: Tenant) => {
    updateTenantStatus(tenant.id, 'SUSPENDED', 'Account suspended by Platform Administrator');
  };

  const handleReactivate = (tenant: Tenant) => {
    updateTenantStatus(tenant.id, 'ACTIVE');
  };

  return (
    <div className="space-y-6">
      {/* Platform HQ Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-colors">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Shah Poran Platform Super Admin Gateway</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 font-semibold">
              admin.shahporan.com
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Global agency onboarding gateway, SaaS tenant status management, and cross-boundary infrastructure health.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0 text-xs font-mono">
          <div className="p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg">
            <span className="text-slate-500 block text-[10px]">TOTAL AGENCIES</span>
            <span className="text-slate-900 dark:text-white font-bold">{tenants.length} Workspaces</span>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg">
            <span className="text-slate-500 block text-[10px]">PENDING APPROVAL</span>
            <span className="text-amber-600 dark:text-amber-400 font-bold">{pendingTenants.length} Pending</span>
          </div>
        </div>
      </div>

      {/* Pending Agency Approval Banner */}
      {pendingTenants.length > 0 && (
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-5 space-y-4 shadow-sm">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-400" />
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Agencies Pending Approval & Onboarding Verification</h3>
                <p className="text-xs text-slate-600 dark:text-slate-400">Review IATA accreditation and corporate details before activating workspace.</p>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-amber-700 dark:text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded">
              ACTION REQUIRED
            </span>
          </div>

          <div className="space-y-3">
            {pendingTenants.map(tenant => (
              <div
                key={tenant.id}
                className="bg-white dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs font-mono shadow-sm"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 dark:text-white text-sm font-sans">{tenant.name}</span>
                    <span className="text-slate-400 dark:text-slate-500">·</span>
                    <span className="text-blue-600 dark:text-blue-400">{tenant.slug}.shahporan.com</span>
                  </div>
                  <div className="text-slate-600 dark:text-slate-400 mt-1 font-sans">
                    Legal Name: <span className="text-slate-800 dark:text-slate-200 font-medium">{tenant.branding.legalName || tenant.name}</span> · Phone: {tenant.branding.contactPhone || 'N/A'}
                  </div>
                  <div className="text-slate-500 text-[11px] mt-0.5 font-sans">
                    Address: {tenant.branding.officeAddress || 'N/A'}
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => handleApprove(tenant)}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold font-sans rounded-lg shadow-sm flex items-center gap-1.5 transition-colors"
                  >
                    <Check className="w-3.5 h-3.5" />
                    <span>Approve & Activate</span>
                  </button>
                  <button
                    onClick={() => {
                      setSelectedTenant(tenant);
                      setIsRejectModalOpen(true);
                    }}
                    className="px-3 py-2 bg-slate-100 hover:bg-rose-100 dark:bg-slate-800 dark:hover:bg-rose-950 text-slate-700 dark:text-slate-300 hover:text-rose-700 dark:hover:text-rose-300 border border-slate-300 dark:border-slate-700 font-sans rounded-lg transition-colors"
                  >
                    Reject
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Active Workspaces Directory */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden text-xs shadow-sm transition-colors">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Registered Multi-Tenant Workspaces</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">PostgreSQL 16 isolated shared-schema tenants</p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono">
            <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 uppercase text-[11px] font-sans">
              <tr>
                <th className="py-3 px-4">Agency / Brand</th>
                <th className="py-3 px-4">Domain Routing</th>
                <th className="py-3 px-4">Currency / Timezone</th>
                <th className="py-3 px-4 text-center">RLS Status</th>
                <th className="py-3 px-4 text-center">Manage Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {tenants.map(tenant => {
                const isActive = tenant.status === 'ACTIVE';
                return (
                  <tr key={tenant.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-sans">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-7 h-7 rounded-md flex items-center justify-center font-bold text-white text-xs shrink-0 shadow-sm"
                          style={{ backgroundColor: tenant.branding.primaryColor }}
                        >
                          {tenant.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-semibold text-slate-900 dark:text-white">{tenant.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono">UUID: {tenant.id.substring(0, 18)}...</div>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <div className="text-blue-600 dark:text-blue-400 font-semibold">{tenant.customDomain || `${tenant.slug}.shahporan.com`}</div>
                      <div className="text-[10px] text-slate-500">
                        {tenant.customDomainVerifiedAt ? 'SSL Handshake Verified' : 'Standard Subdomain Routing'}
                      </div>
                    </td>

                    <td className="py-3 px-4">
                      <span className="font-bold text-slate-900 dark:text-white">{tenant.currency}</span>
                      <span className="text-slate-400 dark:text-slate-500 mx-1">·</span>
                      <span className="text-slate-600 dark:text-slate-400">{tenant.timezone}</span>
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                        tenant.status === 'ACTIVE' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20' :
                        tenant.status === 'PENDING_APPROVAL' ? 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20' :
                        tenant.status === 'SUSPENDED' ? 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20' :
                        'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700'
                      }`}>
                        {tenant.status}
                      </span>
                    </td>

                    <td className="py-3 px-4 text-center font-sans">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => switchTenant(tenant.id)}
                          className="px-2.5 py-1 text-xs bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-blue-600 dark:text-blue-400 rounded transition-colors flex items-center gap-1 border border-slate-200 dark:border-slate-700"
                        >
                          <span>Enter Workspace</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>

                        {isActive ? (
                          <button
                            onClick={() => handleSuspend(tenant)}
                            className="px-2 py-1 text-[11px] text-rose-600 dark:text-rose-400 hover:underline"
                          >
                            Suspend
                          </button>
                        ) : (
                          <button
                            onClick={() => handleReactivate(tenant)}
                            className="px-2 py-1 text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline"
                          >
                            Activate
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reject Modal */}
      {isRejectModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-md w-full p-6 shadow-2xl relative transition-colors">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2">Reject Agency Registration</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              State the reason for rejection (e.g. invalid IATA credentials, incomplete trade license).
            </p>
            <textarea
              rows={3}
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              placeholder="Enter rejection explanation..."
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded-lg p-2.5 text-xs text-slate-900 dark:text-white mb-4"
            />
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setIsRejectModalOpen(false)}
                className="px-3 py-1.5 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleReject}
                className="px-4 py-1.5 text-xs bg-rose-600 hover:bg-rose-500 text-white font-semibold rounded-lg shadow-sm"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

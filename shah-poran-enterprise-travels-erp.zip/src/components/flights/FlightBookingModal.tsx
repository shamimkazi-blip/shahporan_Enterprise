import React, { useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { GdsFlightAdapter, FlightSearchCriteria } from '../../services/integrations/gdsAdapter';
import { FlightOffer } from '../../types';
import { Search, X, Check, Plane, AlertCircle } from 'lucide-react';

interface FlightBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FlightBookingModal: React.FC<FlightBookingModalProps> = ({ isOpen, onClose }) => {
  const { currentTenant, customers, addCustomer, issueFlightTicket } = useTenant();

  const [origin, setOrigin] = useState('DAC');
  const [destination, setDestination] = useState('JED');
  const [departureDate, setDepartureDate] = useState('2026-11-15');
  const [passengers, setPassengers] = useState(1);
  const [searchResults, setSearchResults] = useState<FlightOffer[]>([]);
  const [selectedOffer, setSelectedOffer] = useState<FlightOffer | null>(null);

  // Customer selection or fast create
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(customers[0]?.id || '');
  const [isCreatingCustomer, setIsCreatingCustomer] = useState(false);
  const [newCustFirst, setNewCustFirst] = useState('');
  const [newCustLast, setNewCustLast] = useState('');
  const [newCustPhone, setNewCustPhone] = useState('');
  const [newCustPassport, setNewCustPassport] = useState('');

  // Ticketing feedback
  const [issuedResult, setIssuedResult] = useState<{ ticketNumber: string; pnr: string; jvNumber: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const criteria: FlightSearchCriteria = {
      origin,
      destination,
      departureDate,
      passengers,
    };
    const results = GdsFlightAdapter.searchFlights(criteria);
    setSearchResults(results);
    if (results.length > 0) {
      setSelectedOffer(results[0]);
    }
  };

  const handleIssueTicket = () => {
    if (!selectedOffer) return;
    setIsSubmitting(true);
    setErrorMessage('');

    try {
      let customerId = selectedCustomerId;
      let customerName = '';

      if (isCreatingCustomer) {
        if (!newCustFirst || !newCustLast || !newCustPhone) {
          setErrorMessage('Please fill in required traveler first name, last name, and phone.');
          setIsSubmitting(false);
          return;
        }
        const created = addCustomer({
          firstName: newCustFirst,
          lastName: newCustLast,
          phone: newCustPhone,
          passportNumber: newCustPassport || undefined,
          nationality: 'BGD',
        });
        customerId = created.id;
        customerName = `${created.firstName} ${created.lastName}`;
      } else {
        const found = customers.find(c => c.id === customerId);
        if (!found) {
          setErrorMessage('Please select a customer traveler.');
          setIsSubmitting(false);
          return;
        }
        customerName = `${found.firstName} ${found.lastName}`;
      }

      const pnr = GdsFlightAdapter.generatePnr();
      const ticketNumber = GdsFlightAdapter.generateTicketNumber(selectedOffer.airlineCode);
      const pricing = GdsFlightAdapter.calculatePricing(selectedOffer.baseFare, selectedOffer.taxes);

      const result = issueFlightTicket({
        customerId,
        customerName,
        pnr,
        ticketNumber,
        airlineCode: selectedOffer.airlineCode,
        airlineName: selectedOffer.airlineName,
        route: `${selectedOffer.origin}-${selectedOffer.destination}`,
        departureDate: `${departureDate}T${selectedOffer.departureTime}:00Z`,
        flightNumber: selectedOffer.flightNumber,
        cabinClass: 'ECONOMY',
        gdsSource: selectedOffer.gdsSource,
        baseFare: pricing.baseFare,
        taxes: pricing.taxes,
        commissionEarned: pricing.commissionEarned,
        aitTax: pricing.aitTax,
        netCost: pricing.netCost,
        sellingPrice: pricing.sellingPrice,
      });

      setIssuedResult({
        ticketNumber: result.ticket.ticketNumber,
        pnr: result.ticket.pnr,
        jvNumber: result.journalEntry.entryNumber,
      });
    } catch (err: any) {
      setErrorMessage(err.message || 'Ticketing failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-2xl w-full p-6 shadow-2xl relative my-8 transition-colors">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white transition-colors"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5 border-b border-slate-100 dark:border-slate-800 pb-4">
          <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center">
            <Plane className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white tracking-tight">GDS Live Flight Search & Ticket Issuance</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Direct connection via Amadeus / Sabre Adapter · Auto-posts balanced General Ledger JV
            </p>
          </div>
        </div>

        {issuedResult ? (
          <div className="py-6 text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-slate-900 dark:text-white">Flight Ticket Issued Successfully</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Electronic ticket generated and balanced double-entry journal posted in real time.
              </p>
            </div>

            <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg p-4 font-mono text-xs max-w-md mx-auto text-left space-y-2">
              <div className="flex justify-between">
                <span className="text-slate-500">Airline PNR:</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{issuedResult.pnr}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Ticket Number:</span>
                <span className="text-slate-900 dark:text-white font-semibold">{issuedResult.ticketNumber}</span>
              </div>
              <div className="flex justify-between border-t border-slate-200 dark:border-slate-800 pt-2">
                <span className="text-slate-500">Posted Journal Entry:</span>
                <span className="font-bold text-amber-600 dark:text-amber-400">{issuedResult.jvNumber}</span>
              </div>
            </div>

            <div className="pt-2 flex justify-center gap-3">
              <button
                onClick={() => {
                  setIssuedResult(null);
                  setSelectedOffer(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg transition-colors"
              >
                Issue Another Ticket
              </button>
              <button
                onClick={onClose}
                className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            {/* Search Controls */}
            <form onSubmit={handleSearch} className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-950 p-4 rounded-lg border border-slate-200 dark:border-slate-800">
              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">Origin (Airport)</label>
                <input
                  type="text"
                  value={origin}
                  onChange={e => setOrigin(e.target.value.toUpperCase())}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-900 dark:text-white font-mono uppercase focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">Destination</label>
                <input
                  type="text"
                  value={destination}
                  onChange={e => setDestination(e.target.value.toUpperCase())}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-900 dark:text-white font-mono uppercase focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-600 dark:text-slate-400 mb-1">Departure Date</label>
                <input
                  type="date"
                  value={departureDate}
                  onChange={e => setDepartureDate(e.target.value)}
                  className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md px-2.5 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                  required
                />
              </div>

              <div className="flex items-end">
                <button
                  type="submit"
                  className="w-full px-3 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-md transition-colors flex items-center justify-center gap-1.5"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>Search GDS</span>
                </button>
              </div>
            </form>

            {/* Flight Results */}
            {searchResults.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-800 dark:text-slate-300 flex items-center justify-between">
                  <span>Available GDS Flight Offers ({searchResults.length})</span>
                  <span className="text-[11px] font-mono text-slate-500">Amadeus / Sabre Real-time</span>
                </div>

                <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
                  {searchResults.map(offer => {
                    const isSelected = selectedOffer?.id === offer.id;
                    return (
                      <div
                        key={offer.id}
                        onClick={() => setSelectedOffer(offer)}
                        className={`p-3 rounded-lg border text-xs cursor-pointer transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-blue-50 dark:bg-blue-600/10 border-blue-500 text-slate-900 dark:text-white'
                            : 'bg-white dark:bg-slate-950/70 border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:border-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold font-mono text-slate-900 dark:text-white">{offer.airlineCode} {offer.flightNumber}</span>
                            <span className="text-slate-400 dark:text-slate-500">·</span>
                            <span>{offer.airlineName}</span>
                            <span className="text-[10px] font-mono bg-slate-100 dark:bg-slate-800 px-1 rounded text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700">
                              {offer.gdsSource}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 font-mono">
                            {offer.departureTime} ({offer.origin}) ➔ {offer.arrivalTime} ({offer.destination}) · {offer.duration} · {offer.stops === 0 ? 'Non-stop' : `${offer.stops} Stop`}
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="font-mono font-bold text-slate-900 dark:text-white">
                            {offer.recommendedSellingPrice.toLocaleString()} {currentTenant?.currency || 'BDT'}
                          </div>
                          <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-medium">
                            Net Cost: {offer.netCost.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Traveler Assignment */}
            {selectedOffer && (
              <div className="p-4 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-900 dark:text-white">Traveler / Passenger Information</span>
                  <button
                    type="button"
                    onClick={() => setIsCreatingCustomer(!isCreatingCustomer)}
                    className="text-[11px] text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    {isCreatingCustomer ? 'Select Existing Customer' : '+ Register New Traveler'}
                  </button>
                </div>

                {isCreatingCustomer ? (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <input
                      type="text"
                      placeholder="First Name *"
                      value={newCustFirst}
                      onChange={e => setNewCustFirst(e.target.value)}
                      className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="Last Name *"
                      value={newCustLast}
                      onChange={e => setNewCustLast(e.target.value)}
                      className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="Phone *"
                      value={newCustPhone}
                      onChange={e => setNewCustPhone(e.target.value)}
                      className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-900 dark:text-white"
                    />
                    <input
                      type="text"
                      placeholder="Passport No"
                      value={newCustPassport}
                      onChange={e => setNewCustPassport(e.target.value)}
                      className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-xs text-slate-900 dark:text-white font-mono"
                    />
                  </div>
                ) : (
                  <select
                    value={selectedCustomerId}
                    onChange={e => setSelectedCustomerId(e.target.value)}
                    className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md px-3 py-1.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-blue-500"
                  >
                    {customers.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.firstName} {c.lastName} ({c.phone}) - Passport: {c.passportNumber || 'N/A'}
                      </option>
                    ))}
                  </select>
                )}

                {/* Accounting Impact Preview */}
                <div className="bg-white dark:bg-slate-900 p-2.5 rounded border border-slate-200 dark:border-slate-800/80 text-[11px] font-mono text-slate-600 dark:text-slate-400 space-y-1">
                  <div className="text-slate-800 dark:text-slate-300 font-sans font-semibold text-xs mb-1">
                    Automated Double-Entry Accounting Entry
                  </div>
                  <div className="flex justify-between">
                    <span>DR Accounts Receivable (Customer):</span>
                    <span className="text-slate-900 dark:text-white font-semibold">+{selectedOffer.recommendedSellingPrice.toLocaleString()} {currentTenant?.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CR Flight Ticketing Revenue:</span>
                    <span className="text-slate-900 dark:text-white font-semibold">+{selectedOffer.recommendedSellingPrice.toLocaleString()} {currentTenant?.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>DR Cost of Sales (Net Flight Cost):</span>
                    <span className="text-slate-900 dark:text-white font-semibold">+{selectedOffer.netCost.toLocaleString()} {currentTenant?.currency}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>CR IATA BSP Clearing / Airline Payable:</span>
                    <span className="text-slate-900 dark:text-white font-semibold">+{selectedOffer.netCost.toLocaleString()} {currentTenant?.currency}</span>
                  </div>
                </div>

                {errorMessage && (
                  <div className="p-2.5 bg-rose-500/10 border border-rose-500/30 rounded text-xs text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <div className="pt-2 flex justify-end gap-3">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleIssueTicket}
                    disabled={isSubmitting}
                    className="px-5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
                  >
                    <Plane className="w-3.5 h-3.5" />
                    <span>{isSubmitting ? 'Issuing Ticket...' : 'Confirm & Issue Ticket'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

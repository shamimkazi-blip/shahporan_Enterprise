import React, { useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { FlightTicket } from '../../types';
import { 
  Plane, 
  Search, 
  Plus, 
  FileText, 
  CheckCircle, 
  Clock, 
  ExternalLink,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

interface FlightTicketingViewProps {
  onOpenIssueModal: () => void;
  onNavigateToAccounting: () => void;
}

export const FlightTicketingView: React.FC<FlightTicketingViewProps> = ({ 
  onOpenIssueModal,
  onNavigateToAccounting 
}) => {
  const { currentTenant, flightTickets, journalEntries } = useTenant();
  const currency = currentTenant?.currency || 'BDT';

  const [searchQuery, setSearchQuery] = useState('');
  const [filterAirline, setFilterAirline] = useState('ALL');
  const [selectedTicket, setSelectedTicket] = useState<FlightTicket | null>(null);

  const filteredTickets = flightTickets.filter(ticket => {
    const matchesSearch = 
      ticket.pnr.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.customerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.ticketNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ticket.route.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesAirline = filterAirline === 'ALL' || ticket.airlineCode === filterAirline;

    return matchesSearch && matchesAirline;
  });

  const uniqueAirlines = Array.from(new Set(flightTickets.map(t => t.airlineCode)));

  return (
    <div className="space-y-6">
      {/* Header and Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm transition-colors">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Flight Ticketing & GDS Operations</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 font-semibold">
              AMADEUS & SABRE READY
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Real-time electronic ticket issuance with IATA BSP clearing and automated double-entry ledger integration.
          </p>
        </div>

        <button
          onClick={onOpenIssueModal}
          className="px-4 py-2 text-xs font-semibold text-white rounded-lg shadow-sm flex items-center gap-1.5 transition-all shrink-0"
          style={{ backgroundColor: 'var(--brand-primary)' }}
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Search & Issue Ticket</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-white dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800/80 p-3 rounded-lg shadow-sm transition-colors">
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by PNR, passenger, or ticket..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-md pl-9 pr-3 py-1.5 text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <span className="text-xs text-slate-500 dark:text-slate-400 shrink-0">Airline:</span>
          <select
            value={filterAirline}
            onChange={e => setFilterAirline(e.target.value)}
            className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300 rounded-md px-3 py-1.5 focus:outline-none focus:border-blue-500"
          >
            <option value="ALL">All Airlines ({flightTickets.length})</option>
            {uniqueAirlines.map(code => (
              <option key={code} value={code}>{code}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Tickets Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm transition-colors">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Airline & Flight</th>
                <th className="py-3 px-4">Passenger / CRM</th>
                <th className="py-3 px-4">PNR / Ticket Number</th>
                <th className="py-3 px-4">Route</th>
                <th className="py-3 px-4 text-right">Net Cost</th>
                <th className="py-3 px-4 text-right">Selling Price</th>
                <th className="py-3 px-4 text-right">Agency Margin</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80 font-mono">
              {filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-slate-500 font-sans">
                    No flight tickets matching your criteria.
                  </td>
                </tr>
              ) : (
                filteredTickets.map(ticket => {
                  const profit = ticket.sellingPrice - ticket.netCost;

                  return (
                    <tr 
                      key={ticket.id}
                      className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3 px-4 font-sans">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded bg-slate-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-bold font-mono text-[11px] flex items-center justify-center shrink-0 border border-slate-200 dark:border-slate-700">
                            {ticket.airlineCode}
                          </div>
                          <div>
                            <div className="font-semibold text-slate-900 dark:text-white">{ticket.airlineName}</div>
                            <div className="text-[11px] font-mono text-slate-500 dark:text-slate-400">{ticket.flightNumber} · {ticket.gdsSource}</div>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-4 font-sans text-slate-800 dark:text-slate-200">
                        <div className="font-medium">{ticket.customerName}</div>
                        <div className="text-[11px] text-slate-500 font-mono">ID: {ticket.customerId}</div>
                      </td>

                      <td className="py-3 px-4">
                        <div className="font-bold text-amber-600 dark:text-amber-400 tracking-wider">{ticket.pnr}</div>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400">{ticket.ticketNumber}</div>
                      </td>

                      <td className="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200">
                        {ticket.route}
                      </td>

                      <td className="py-3 px-4 text-right text-slate-600 dark:text-slate-400">
                        {ticket.netCost.toLocaleString()} <span className="text-[10px] text-slate-400 dark:text-slate-500 font-sans">{currency}</span>
                      </td>

                      <td className="py-3 px-4 text-right font-bold text-slate-900 dark:text-white">
                        {ticket.sellingPrice.toLocaleString()} <span className="text-[10px] text-slate-400 dark:text-slate-500 font-sans">{currency}</span>
                      </td>

                      <td className="py-3 px-4 text-right text-emerald-600 dark:text-emerald-400 font-semibold">
                        +{profit.toLocaleString()} <span className="text-[10px] text-emerald-500/70 font-sans">{currency}</span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 font-medium">
                          {ticket.status}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => setSelectedTicket(ticket)}
                          className="px-2.5 py-1 text-[11px] text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-sans font-medium hover:underline flex items-center justify-center gap-1 mx-auto"
                        >
                          <span>Details</span>
                          <ChevronRight className="w-3 h-3" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Ticket Details Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-lg w-full p-6 shadow-2xl relative transition-colors">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">Electronic Ticket Passenger Receipt</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 font-mono">PNR: {selectedTicket.pnr} · Ticket: {selectedTicket.ticketNumber}</p>
              </div>
              <button
                onClick={() => setSelectedTicket(null)}
                className="text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs font-mono">
              <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">Passenger Name:</span>
                  <span className="text-slate-900 dark:text-white font-sans font-semibold">{selectedTicket.customerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Airline / Carrier:</span>
                  <span className="text-slate-800 dark:text-white">{selectedTicket.airlineName} ({selectedTicket.airlineCode})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Flight / Route:</span>
                  <span className="text-slate-800 dark:text-white">{selectedTicket.flightNumber} ({selectedTicket.route})</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">GDS Provider:</span>
                  <span className="text-slate-800 dark:text-white">{selectedTicket.gdsSource} Integration Adapter</span>
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-950 p-3 rounded-lg border border-slate-200 dark:border-slate-800 space-y-1.5">
                <div className="text-[11px] font-sans font-semibold text-slate-600 dark:text-slate-400 mb-2">
                  Fare & Tax Breakdown (IATA Standard)
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Gross Base Fare:</span>
                  <span>{selectedTicket.baseFare.toLocaleString()} {currency}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>Taxes & Airport Surcharges:</span>
                  <span>+{selectedTicket.taxes.toLocaleString()} {currency}</span>
                </div>
                <div className="flex justify-between text-emerald-600 dark:text-emerald-400">
                  <span>Commission Earned (7%):</span>
                  <span>-{selectedTicket.commissionEarned.toLocaleString()} {currency}</span>
                </div>
                <div className="flex justify-between text-slate-600 dark:text-slate-400">
                  <span>AIT (Advance Income Tax 0.3%):</span>
                  <span>+{selectedTicket.aitTax.toLocaleString()} {currency}</span>
                </div>
                <div className="flex justify-between border-t border-slate-200 dark:border-slate-800 pt-1 font-bold text-slate-900 dark:text-white">
                  <span>Net Cost to Airline:</span>
                  <span>{selectedTicket.netCost.toLocaleString()} {currency}</span>
                </div>
                <div className="flex justify-between font-bold text-emerald-600 dark:text-emerald-400">
                  <span>Client Selling Price:</span>
                  <span>{selectedTicket.sellingPrice.toLocaleString()} {currency}</span>
                </div>
              </div>

              {selectedTicket.journalEntryId && (
                <div className="p-3 bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 rounded-lg flex items-center justify-between font-sans">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <div>
                      <div className="text-xs text-slate-900 dark:text-white font-semibold">Ledger Transaction Verified</div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">Linked to JV {selectedTicket.journalEntryId}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      setSelectedTicket(null);
                      onNavigateToAccounting();
                    }}
                    className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 font-semibold flex items-center gap-1"
                  >
                    <span>View in Ledger</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>

            <div className="mt-5 flex justify-end">
              <button
                onClick={() => setSelectedTicket(null)}
                className="px-4 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-300 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 rounded-lg transition-colors"
              >
                Close Receipt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

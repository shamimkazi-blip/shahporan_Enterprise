import React, { useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { UmrahPackage, PackageStatus } from '../../types';
import { Compass, Plus, Calendar, Hotel } from 'lucide-react';

export const UmrahPackagesView: React.FC = () => {
  const { currentTenant, umrahPackages, addUmrahPackage, updateUmrahPackageStatus } = useTenant();
  const currency = currentTenant?.currency || 'BDT';

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [batchCode, setBatchCode] = useState('');
  const [title, setTitle] = useState('');
  const [season, setSeason] = useState<UmrahPackage['season']>('REGULAR');
  const [departureDate, setDepartureDate] = useState('2026-12-01');
  const [returnDate, setReturnDate] = useState('2026-12-15');
  const [durationDays, setDurationDays] = useState(14);
  const [makkahHotel, setMakkahHotel] = useState('Fairmont Clock Royal Tower');
  const [madinahHotel, setMadinahHotel] = useState('Pullman Zamzam Madina');
  const [capacity, setCapacity] = useState(50);
  const [pricePerPerson, setPricePerPerson] = useState(245000);

  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  const filteredPackages = umrahPackages.filter(p => 
    statusFilter === 'ALL' || p.status === statusFilter
  );

  const handleCreateBatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!batchCode || !title) return;

    addUmrahPackage({
      batchCode: batchCode.toUpperCase(),
      title,
      season,
      departureDate,
      returnDate,
      durationDays,
      makkahHotel,
      makkahHotelStars: 5,
      madinahHotel,
      madinahHotelStars: 5,
      capacity,
      enrolledPilgrims: 0,
      pricePerPerson,
      status: 'PLANNING',
      includedServices: ['Group Air Ticket', '5-Star Hotel Stay', 'Luxury Transport', 'Visa Processing', 'Ziyarah Tours'],
    });

    setIsModalOpen(false);
    setBatchCode('');
    setTitle('');
  };

  const getStatusBadge = (status: PackageStatus) => {
    switch (status) {
      case 'PLANNING':
        return 'text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700';
      case 'OPEN_FOR_BOOKING':
        return 'text-blue-600 dark:text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'VISA_PROCESSING':
        return 'text-amber-600 dark:text-amber-400 bg-amber-500/10 border-amber-500/20';
      case 'CONFIRMED':
        return 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      case 'DEPARTED':
        return 'text-purple-600 dark:text-purple-400 bg-purple-500/10 border-purple-500/20';
      case 'COMPLETED':
        return 'text-slate-500 bg-slate-100 dark:bg-slate-900 border-slate-200 dark:border-slate-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm transition-colors">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">Umrah & Hajj Package Batch Operations</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 font-semibold">
              MINISTRY OF HAJJ ALIGNED
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Group batch allotments, Makkah & Madinah hotel reservations, pilgrim rooming, and visa pipeline tracking.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="px-4 py-2 text-xs font-semibold text-white rounded-lg shadow-sm flex items-center gap-1.5 transition-all shrink-0"
          style={{ backgroundColor: 'var(--brand-primary)' }}
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Create New Batch</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg overflow-x-auto text-xs shadow-sm">
        {['ALL', 'PLANNING', 'OPEN_FOR_BOOKING', 'VISA_PROCESSING', 'CONFIRMED'].map(tab => (
          <button
            key={tab}
            onClick={() => setStatusFilter(tab)}
            className={`px-3 py-1.5 rounded-md font-medium whitespace-nowrap transition-colors ${
              statusFilter === tab
                ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
            }`}
          >
            {tab.replace(/_/g, ' ')}
          </button>
        ))}
      </div>

      {/* Batches Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredPackages.map(pkg => {
          const occupancyPercent = Math.round((pkg.enrolledPilgrims / pkg.capacity) * 100);

          return (
            <div
              key={pkg.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between hover:border-slate-300 dark:hover:border-slate-700 transition-all"
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <span className="font-mono font-bold text-xs text-amber-600 dark:text-amber-400 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
                    {pkg.batchCode}
                  </span>
                  <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${getStatusBadge(pkg.status)}`}>
                    {pkg.status.replace(/_/g, ' ')}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-2 leading-snug">
                  {pkg.title}
                </h3>

                <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300 my-4">
                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <Calendar className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 shrink-0" />
                    <span>{pkg.departureDate} ➔ {pkg.returnDate} ({pkg.durationDays} Days)</span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <Hotel className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 shrink-0" />
                    <span className="truncate">Makkah: {pkg.makkahHotel}</span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
                    <Hotel className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />
                    <span className="truncate">Madinah: {pkg.madinahHotel}</span>
                  </div>
                </div>

                {/* Capacity Progress Bar */}
                <div className="space-y-1 mb-4">
                  <div className="flex justify-between text-[11px] font-mono">
                    <span className="text-slate-500 dark:text-slate-400">Pilgrims Enrolled:</span>
                    <span className="text-slate-900 dark:text-white font-semibold">
                      {pkg.enrolledPilgrims} / {pkg.capacity} ({occupancyPercent}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-100 dark:bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-200 dark:border-slate-800">
                    <div
                      className="bg-emerald-500 h-full rounded-full transition-all"
                      style={{ width: `${Math.min(occupancyPercent, 100)}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-[10px] text-slate-500 uppercase font-mono">Package Rate</div>
                  <div className="text-sm font-bold text-slate-900 dark:text-white font-mono">
                    {pkg.pricePerPerson.toLocaleString()} <span className="text-xs text-slate-500 dark:text-slate-400 font-sans">{currency}</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <select
                    value={pkg.status}
                    onChange={e => updateUmrahPackageStatus(pkg.id, e.target.value as PackageStatus)}
                    className="bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 text-[11px] text-slate-700 dark:text-slate-300 rounded px-2 py-1 focus:outline-none"
                  >
                    <option value="PLANNING">Planning</option>
                    <option value="OPEN_FOR_BOOKING">Booking Open</option>
                    <option value="VISA_PROCESSING">Visa Proc.</option>
                    <option value="CONFIRMED">Confirmed</option>
                    <option value="DEPARTED">Departed</option>
                    <option value="COMPLETED">Completed</option>
                  </select>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create Batch Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/60 dark:bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl max-w-lg w-full p-6 shadow-2xl relative transition-colors">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800 mb-4">
              <h3 className="text-base font-bold text-slate-900 dark:text-white">Create Umrah / Hajj Batch</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-700 dark:hover:text-white">✕</button>
            </div>

            <form onSubmit={handleCreateBatch} className="space-y-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Batch Code *</label>
                  <input
                    type="text"
                    placeholder="e.g. UMR-2027-JAN-5S"
                    value={batchCode}
                    onChange={e => setBatchCode(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white font-mono uppercase"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Season</label>
                  <select
                    value={season}
                    onChange={e => setSeason(e.target.value as any)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
                  >
                    <option value="REGULAR">Regular Season</option>
                    <option value="RAMADAN">Ramadan Special</option>
                    <option value="SHAWWAL">Shawwal</option>
                    <option value="HAJJ">Hajj Season</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-600 dark:text-slate-400 mb-1">Package Title *</label>
                <input
                  type="text"
                  placeholder="e.g. 14-Day VIP Umrah Package with Swissôtel"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Departure Date</label>
                  <input
                    type="date"
                    value={departureDate}
                    onChange={e => setDepartureDate(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Return Date</label>
                  <input
                    type="date"
                    value={returnDate}
                    onChange={e => setReturnDate(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Makkah Hotel Allotment</label>
                  <input
                    type="text"
                    value={makkahHotel}
                    onChange={e => setMakkahHotel(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Madinah Hotel Allotment</label>
                  <input
                    type="text"
                    value={madinahHotel}
                    onChange={e => setMadinahHotel(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Total Pilgrim Capacity</label>
                  <input
                    type="number"
                    value={capacity}
                    onChange={e => setCapacity(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white font-mono"
                    min={1}
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-600 dark:text-slate-400 mb-1">Price Per Person ({currency})</label>
                  <input
                    type="number"
                    value={pricePerPerson}
                    onChange={e => setPricePerPerson(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white font-mono"
                    min={1}
                    required
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 text-slate-500 hover:text-slate-800 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-lg shadow-sm"
                >
                  Create Batch
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

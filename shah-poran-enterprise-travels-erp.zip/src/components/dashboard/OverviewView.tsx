import React from 'react';
import { useTenant } from '../../context/TenantContext';
import { 
  PlaneTakeoff, 
  Wallet, 
  Users, 
  FileText, 
  ArrowUpRight, 
  ShieldCheck, 
  CheckCircle2, 
  Plus,
  Sparkles
} from 'lucide-react';

interface OverviewViewProps {
  onNavigate: (view: string) => void;
  onOpenIssueModal: () => void;
  onOpenAIModal?: () => void;
}

export const OverviewView: React.FC<OverviewViewProps> = ({ onNavigate, onOpenIssueModal, onOpenAIModal }) => {
  const { 
    currentTenant, 
    isSuperAdmin, 
    flightTickets, 
    journalEntries, 
    umrahPackages, 
    accounts,
    activeDomain 
  } = useTenant();

  const currency = currentTenant?.currency || 'BDT';

  // Compute metrics
  const totalRevenue = flightTickets.reduce((acc, t) => acc + t.sellingPrice, 0);
  const totalNetCost = flightTickets.reduce((acc, t) => acc + t.netCost, 0);
  const totalGrossProfit = totalRevenue - totalNetCost;
  const totalTickets = flightTickets.length;
  
  const cashAccounts = accounts.filter(a => a.type === 'ASSET' && (a.code === '1010' || a.code === '1020'));
  const totalLiquidCash = cashAccounts.reduce((acc, a) => acc + a.currentBalance, 0);

  const totalPilgrims = umrahPackages.reduce((acc, p) => acc + p.enrolledPilgrims, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner & Context Summary */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-colors">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">
              {isSuperAdmin ? 'Shah Poran Platform Administration' : currentTenant?.name}
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 font-semibold">
              {isSuperAdmin ? 'SUPER_ADMIN_PLANE' : `${currentTenant?.status} · ${currency}`}
            </span>
          </div>
          <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
            {isSuperAdmin
              ? 'Multi-tenant control plane overseeing all white-label travel agencies, RLS boundary health, and tenant approvals.'
              : `Operating as IATA/GDS agency partner on custom domain: ${activeDomain}. PostgreSQL Row-Level Security active.`}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenIssueModal}
            className="px-3.5 py-2 text-xs font-semibold text-white rounded-lg shadow-sm flex items-center gap-1.5 transition-all"
            style={{ backgroundColor: 'var(--brand-primary)' }}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Issue Ticket</span>
          </button>
          <button
            onClick={onOpenAIModal}
            className="px-3.5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 rounded-lg shadow-sm flex items-center gap-1.5 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span>AI Agency Audit</span>
          </button>
          <button
            onClick={() => onNavigate('security')}
            className="px-3.5 py-2 text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 rounded-lg flex items-center gap-1.5 transition-colors"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>RLS Security Audit</span>
          </button>
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm transition-colors">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2 font-medium">
            <span>Flight Gross Bookings</span>
            <PlaneTakeoff className="w-4 h-4 text-blue-600 dark:text-blue-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white tracking-tight">
            <span className="text-xs text-slate-500 font-sans mr-1">{currency}</span>
            {totalRevenue.toLocaleString()}
          </div>
          <div className="mt-2 text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 font-mono font-medium">
            <span>+{totalGrossProfit.toLocaleString()} {currency}</span>
            <span className="text-slate-500 font-sans">net agency margin</span>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm transition-colors">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2 font-medium">
            <span>Total Issued Tickets</span>
            <FileText className="w-4 h-4 text-amber-500 dark:text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white tracking-tight">
            {totalTickets}
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
            <span>100% synced with General Ledger</span>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm transition-colors">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2 font-medium">
            <span>Umrah & Hajj Pilgrims</span>
            <Users className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white tracking-tight">
            {totalPilgrims}
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
            <span>Across {umrahPackages.length} active hotel batches</span>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm transition-colors">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2 font-medium">
            <span>Liquid Cash & Bank Reserves</span>
            <Wallet className="w-4 h-4 text-purple-600 dark:text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white tracking-tight">
            <span className="text-xs text-slate-500 font-sans mr-1">{currency}</span>
            {totalLiquidCash.toLocaleString()}
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400">
            <span>Real-time Double-Entry Balance</span>
          </div>
        </div>
      </div>

      {/* Two Column Section: Recent Flight Tickets & Recent JVs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Recent Flight Tickets */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between transition-colors">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">Recent Flight Tickets (GDS Issued)</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Amadeus & Sabre automated ticketing feed</p>
              </div>
              <button
                onClick={() => onNavigate('flights')}
                className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors flex items-center gap-1 font-semibold"
              >
                <span>View All ({flightTickets.length})</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {flightTickets.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg text-slate-500 text-xs">
                No flight tickets issued yet. Click "Issue Flight Ticket" above.
              </div>
            ) : (
              <div className="space-y-2.5">
                {flightTickets.slice(0, 4).map(ticket => (
                  <div
                    key={ticket.id}
                    className="p-3 bg-slate-50 dark:bg-slate-950/60 border border-slate-200/90 dark:border-slate-800/80 rounded-lg flex items-center justify-between text-xs hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                  >
                    <div className="min-w-0 pr-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-slate-900 dark:text-white">{ticket.airlineCode} {ticket.flightNumber}</span>
                        <span className="text-slate-400 dark:text-slate-500">·</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">{ticket.route}</span>
                        <span className="px-1.5 py-0.5 rounded text-[10px] font-mono bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20">
                          PNR: {ticket.pnr}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-400 mt-1 truncate">
                        <span>{ticket.customerName}</span>
                        <span className="mx-1 text-slate-400 dark:text-slate-600">·</span>
                        <span className="font-mono text-slate-500">{ticket.ticketNumber}</span>
                      </div>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="font-mono font-bold text-slate-900 dark:text-white">
                        {ticket.sellingPrice.toLocaleString()} {currency}
                      </div>
                      <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono font-medium">
                        +{(ticket.sellingPrice - ticket.netCost).toLocaleString()} profit
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500">
            <span>GDS Engine: <span className="text-slate-700 dark:text-slate-300 font-medium">Amadeus & Sabre Active</span></span>
            <span>AIT 0.3% IATA compliant</span>
          </div>
        </div>

        {/* Right: Double-Entry Journal Postings */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm flex flex-col justify-between transition-colors">
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white">General Ledger Postings (JV Feed)</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Strictly balanced double-entry accounting records</p>
              </div>
              <button
                onClick={() => onNavigate('accounting')}
                className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors flex items-center gap-1 font-semibold"
              >
                <span>View Ledger ({journalEntries.length})</span>
                <ArrowUpRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {journalEntries.length === 0 ? (
              <div className="p-8 text-center border border-dashed border-slate-200 dark:border-slate-800 rounded-lg text-slate-500 text-xs">
                No journal entries posted yet.
              </div>
            ) : (
              <div className="space-y-2.5">
                {journalEntries.slice(0, 4).map(entry => {
                  const totalLineDebit = entry.lines.reduce((acc, l) => acc + l.debit, 0);
                  return (
                    <div
                      key={entry.id}
                      className="p-3 bg-slate-50 dark:bg-slate-950/60 border border-slate-200/90 dark:border-slate-800/80 rounded-lg text-xs hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-amber-600 dark:text-amber-400">{entry.entryNumber}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20 font-semibold">
                            {entry.status}
                          </span>
                        </div>
                        <div className="font-mono text-slate-900 dark:text-white font-bold">
                          {totalLineDebit.toLocaleString()} {currency}
                        </div>
                      </div>
                      <div className="text-[11px] text-slate-600 dark:text-slate-400 truncate">
                        {entry.memo}
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1 font-mono">
                        <span>{entry.lines.length} lines balanced</span>
                        <span>{new Date(entry.entryDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="pt-4 mt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500">
            <span>Posting Engine: <span className="text-slate-700 dark:text-slate-300 font-medium">Auto-balanced DR/CR</span></span>
            <span>IFRS 15 / GAAP Standard</span>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { useTenant } from '../../context/TenantContext';
import {
  LayoutDashboard,
  PlaneTakeoff,
  Compass,
  FileCheck2,
  Calculator,
  ShieldAlert,
  Palette,
  Building2,
  Lock,
  Sparkles,
} from 'lucide-react';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenAIModal?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ currentView, onNavigate, onOpenAIModal }) => {
  const { currentTenant, isSuperAdmin, flightTickets, umrahPackages, visaApplications, journalEntries } = useTenant();

  const navItems = [
    {
      id: 'overview',
      label: 'ERP Dashboard',
      icon: LayoutDashboard,
      badge: null,
      agencyOnly: false,
    },
    {
      id: 'flights',
      label: 'Flight Ticketing & GDS',
      icon: PlaneTakeoff,
      badge: flightTickets.length,
      agencyOnly: false,
    },
    {
      id: 'umrah',
      label: 'Umrah & Hajj Batches',
      icon: Compass,
      badge: umrahPackages.length,
      agencyOnly: false,
    },
    {
      id: 'visa',
      label: 'Visa Document Vault',
      icon: FileCheck2,
      badge: visaApplications.length,
      agencyOnly: false,
    },
    {
      id: 'accounting',
      label: 'Double-Entry Accounting',
      icon: Calculator,
      badge: journalEntries.length,
      agencyOnly: false,
    },
    {
      id: 'security',
      label: 'RLS & Security Sandbox',
      icon: ShieldAlert,
      badge: '0% Leak',
      badgeColor: 'text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
      agencyOnly: false,
    },
    {
      id: 'whitelabel',
      label: 'White-Label Branding',
      icon: Palette,
      badge: null,
      agencyOnly: true,
    },
    {
      id: 'superadmin',
      label: 'Platform Super Admin',
      icon: Building2,
      badge: isSuperAdmin ? 'HQ' : 'Gateway',
      badgeColor: 'text-blue-600 dark:text-blue-400 bg-blue-500/10 border-blue-500/20',
      agencyOnly: false,
    },
  ];

  return (
    <aside className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col shrink-0 min-h-[calc(100vh-65px)] transition-colors duration-150">
      {/* Agency Identity Banner */}
      <div className="p-4 border-b border-slate-200 dark:border-slate-800/80">
        <div className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-1 flex items-center justify-between">
          <span>Active Organization</span>
          <span className="flex items-center gap-1 text-[10px] text-slate-500">
            <Lock className="w-2.5 h-2.5" />
            RLS Active
          </span>
        </div>
        <div className="text-sm font-semibold text-slate-900 dark:text-white truncate">
          {isSuperAdmin ? 'Shah Poran Platform Core' : currentTenant?.name}
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 font-mono truncate mt-0.5">
          {isSuperAdmin ? 'Postgres Superuser Plane' : `tenant_id: ${currentTenant?.id.substring(0, 13)}...`}
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="p-3 space-y-1 flex-1">
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                isActive
                  ? 'bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white shadow-sm border border-slate-200 dark:border-slate-700'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-slate-100/70 dark:hover:bg-slate-800/50'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <Icon
                  className={`w-4 h-4 ${
                    isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400 dark:text-slate-500'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </div>

              {item.badge !== null && (
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                    item.badgeColor || 'text-slate-600 dark:text-slate-400 bg-slate-100 dark:bg-slate-800 border-slate-200 dark:border-slate-700'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Dedicated AI Copilot Button in Sidebar */}
        <div className="pt-3 mt-2 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={onOpenAIModal}
            className="w-full flex items-center justify-between px-3 py-2.5 rounded-xl bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 hover:from-indigo-500/20 hover:to-pink-500/20 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800/60 font-semibold text-xs transition-all shadow-2xs group cursor-pointer"
          >
            <div className="flex items-center gap-2.5">
              <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400 group-hover:rotate-12 transition-transform" />
              <span>AI Copilot & Advisor</span>
            </div>
            <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-indigo-600 text-white shadow-2xs">
              AI
            </span>
          </button>
        </div>
      </nav>

      {/* Database Session Footer Indicator */}
      <div className="p-4 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400 space-y-1 bg-slate-50 dark:bg-slate-950/40">
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-500">Database Engine:</span>
          <span className="text-slate-800 dark:text-slate-300 font-medium">PostgreSQL 16</span>
        </div>
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-500">Isolation Policy:</span>
          <span className="text-emerald-600 dark:text-emerald-400 font-medium">RESTRICTIVE RLS</span>
        </div>
        <div className="flex items-center justify-between font-mono">
          <span className="text-slate-500">Pooler:</span>
          <span className="text-slate-800 dark:text-slate-300">PgBouncer (Txn)</span>
        </div>
      </div>
    </aside>
  );
};

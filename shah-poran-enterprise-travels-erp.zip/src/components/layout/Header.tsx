import React, { useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { 
  Building2, 
  ShieldCheck, 
  Globe, 
  ChevronDown, 
  Check, 
  Terminal,
  ArrowRightLeft,
  Sun,
  Moon,
  Sparkles
} from 'lucide-react';

interface HeaderProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenIssueModal: () => void;
  onOpenAIModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ currentView, onNavigate, onOpenIssueModal, onOpenAIModal }) => {
  const { 
    tenants, 
    currentTenant, 
    isSuperAdmin, 
    activeDomain, 
    simulatedEdgeHeaders, 
    switchTenant,
    isDarkMode,
    toggleTheme
  } = useTenant();

  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [showEdgeDetails, setShowEdgeDetails] = useState(false);

  const viewTitles: Record<string, string> = {
    overview: 'Workspace Overview',
    flights: 'Flight Ticketing & GDS Operations',
    umrah: 'Umrah & Hajj Batch Operations',
    visa: 'Visa Document Vault & Compliance',
    accounting: 'Double-Entry Accounting Engine',
    security: 'PostgreSQL RLS Security Sandbox',
    whitelabel: 'White-Label Branding & Custom Domain',
    superadmin: 'Platform Super Admin Gateway',
  };

  return (
    <header className="border-b border-slate-200 dark:border-slate-800 bg-white/95 dark:bg-slate-900/90 backdrop-blur sticky top-0 z-30 transition-colors duration-150">
      {/* Edge Routing Indicator Strip */}
      <div className="bg-slate-100 dark:bg-slate-950 px-4 py-1.5 border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 transition-colors">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-slate-700 dark:text-slate-300 font-medium">
            <Globe className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span className="font-mono text-slate-800 dark:text-slate-200 font-semibold">{activeDomain}</span>
          </span>
          <span className="text-slate-400 dark:text-slate-600">|</span>
          <span className="hidden sm:inline-flex items-center gap-1 text-slate-500 dark:text-slate-400">
            <span>TLS 1.3</span>
            <span className="text-slate-400 dark:text-slate-600">·</span>
            <span>Cloudflare SaaS Edge</span>
            <span className="text-slate-400 dark:text-slate-600">·</span>
            <span>PgBouncer RLS Active</span>
          </span>
        </div>

        <button
          onClick={() => setShowEdgeDetails(!showEdgeDetails)}
          className="text-xs text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 transition-colors flex items-center gap-1 font-mono"
        >
          <Terminal className="w-3 h-3" />
          <span>{showEdgeDetails ? 'Hide Edge Headers' : 'Inspect Edge Headers'}</span>
        </button>
      </div>

      {showEdgeDetails && (
        <div className="bg-slate-50 dark:bg-slate-950/95 p-3 px-6 border-b border-slate-200 dark:border-blue-900/40 text-xs font-mono text-slate-700 dark:text-slate-300 grid grid-cols-1 md:grid-cols-4 gap-2 transition-colors">
          <div>
            <span className="text-slate-500 block">X-Forwarded-Host:</span>
            <span className="text-blue-600 dark:text-blue-300">{simulatedEdgeHeaders.host}</span>
          </div>
          <div>
            <span className="text-slate-500 block">X-Tenant-Domain:</span>
            <span className="text-emerald-600 dark:text-emerald-400">{simulatedEdgeHeaders.tenantDomain}</span>
          </div>
          <div>
            <span className="text-slate-500 block">X-Tenant-Slug:</span>
            <span className="text-amber-600 dark:text-amber-300">{simulatedEdgeHeaders.tenantSlug}</span>
          </div>
          <div>
            <span className="text-slate-500 block">SET LOCAL current_tenant_id:</span>
            <span className="text-purple-600 dark:text-purple-300 truncate block">{simulatedEdgeHeaders.dbSessionTenantId}</span>
          </div>
        </div>
      )}

      {/* Main Top Bar */}
      <div className="flex items-center justify-between gap-4 md:gap-8 px-6 py-3.5">
        {/* Zone 1: Brand & Breadcrumb */}
        <div className="flex items-center gap-4 min-w-0">
          <div className="flex items-center gap-3">
            <div 
              className="w-9 h-9 rounded-lg flex items-center justify-center font-bold text-white shadow-sm shrink-0"
              style={{ backgroundColor: isSuperAdmin ? '#2563EB' : 'var(--brand-primary)' }}
            >
              {isSuperAdmin ? 'SP' : (currentTenant?.name.charAt(0) || 'T')}
            </div>
            <div className="min-w-0">
              <div className="text-sm font-semibold text-slate-900 dark:text-white tracking-tight truncate flex items-center gap-2">
                <span>{isSuperAdmin ? 'Shah Poran HQ Platform' : currentTenant?.branding.companyName}</span>
                {isSuperAdmin ? (
                  <span className="text-[10px] bg-blue-500/10 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded font-mono border border-blue-500/20">
                    SUPER_ADMIN
                  </span>
                ) : (
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 px-1.5 py-0.5 rounded font-mono border border-emerald-500/20">
                    {currentTenant?.currency} · RLS ENFORCED
                  </span>
                )}
              </div>
              <div className="text-xs text-slate-500 dark:text-slate-400 truncate">
                {viewTitles[currentView] || 'Console'}
              </div>
            </div>
          </div>
        </div>

        {/* Zone 2: Fast Tenant Context Switcher */}
        <div className="relative">
          <button
            onClick={() => setDropdownOpen(!dropdownOpen)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700/80 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors"
            aria-label="Switch tenant context"
          >
            <ArrowRightLeft className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
            <span className="hidden sm:inline text-slate-500 dark:text-slate-400">Context:</span>
            <span className="font-semibold text-slate-900 dark:text-white">
              {isSuperAdmin ? 'Platform Super Admin' : currentTenant?.name}
            </span>
            <ChevronDown className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
          </button>

          {dropdownOpen && (
            <div className="absolute right-0 mt-2 w-72 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-2 z-50">
              <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-b border-slate-100 dark:border-slate-800">
                Switch Operational Boundary
              </div>
              
              <button
                onClick={() => {
                  switchTenant(null);
                  setDropdownOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors ${
                  isSuperAdmin ? 'bg-blue-50 dark:bg-blue-600/10 text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-700 dark:text-slate-300'
                }`}
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                  <div>
                    <div className="font-medium text-slate-900 dark:text-slate-100">Shah Poran Platform Admin</div>
                    <div className="text-[10px] text-slate-500 font-mono">admin.shahporan.com</div>
                  </div>
                </div>
                {isSuperAdmin && <Check className="w-4 h-4 text-blue-600 dark:text-blue-400" />}
              </button>

              <div className="px-3 pt-2 pb-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider border-t border-slate-100 dark:border-slate-800">
                Agency Workspaces (Isolated by RLS)
              </div>

              {tenants.map(tenant => {
                const active = currentTenant?.id === tenant.id;
                return (
                  <button
                    key={tenant.id}
                    onClick={() => {
                      switchTenant(tenant.id);
                      setDropdownOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800/80 transition-colors ${
                      active ? 'bg-blue-50 dark:bg-blue-600/10 text-blue-600 dark:text-blue-400 font-semibold' : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <div 
                        className="w-3 h-3 rounded-full shrink-0" 
                        style={{ backgroundColor: tenant.branding.primaryColor }}
                      />
                      <div className="truncate">
                        <div className="truncate font-medium text-slate-900 dark:text-slate-100">{tenant.name}</div>
                        <div className="text-[10px] text-slate-500 font-mono truncate">
                          {tenant.customDomain || `${tenant.slug}.shahporan.com`}
                        </div>
                      </div>
                    </div>
                    {active && <Check className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 ml-2" />}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Zone 3: Actions + AI Button + Light/Dark Toggle */}
        <div className="flex items-center gap-2.5 shrink-0">
          {/* AI Copilot Button */}
          <button
            onClick={onOpenAIModal}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 via-purple-600 to-indigo-700 hover:from-indigo-500 hover:to-purple-500 text-white text-xs font-semibold shadow-sm hover:shadow-indigo-500/25 transition-all cursor-pointer border border-indigo-400/30"
            aria-label="Open AI Copilot"
            title="Open AI Copilot (Powered by Gemini 3.8 Flash)"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-pulse" />
            <span className="font-bold">AI Copilot</span>
            <span className="hidden md:inline-flex text-[9px] bg-white/20 px-1 py-0.2 rounded font-mono">
              AI
            </span>
          </button>

          {/* Light / Dark Mode Switcher */}
          <button
            onClick={toggleTheme}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-700 dark:text-slate-200 transition-colors shadow-sm"
            aria-label={isDarkMode ? 'Switch to light mode (white background)' : 'Switch to dark mode (black background)'}
            title={isDarkMode ? 'Switch to light mode' : 'Switch to dark mode'}
          >
            {isDarkMode ? (
              <Sun className="w-4 h-4 text-amber-400" />
            ) : (
              <Moon className="w-4 h-4 text-indigo-600" />
            )}
            <span className="hidden sm:inline font-semibold">{isDarkMode ? 'Dark' : 'Light'}</span>
          </button>

          {!isSuperAdmin ? (
            <button
              onClick={onOpenIssueModal}
              className="px-4 py-2 text-xs font-semibold text-white rounded-lg transition-all shadow-sm flex items-center gap-2"
              style={{ backgroundColor: 'var(--brand-primary)' }}
            >
              <span>Issue Flight Ticket</span>
            </button>
          ) : (
            <button
              onClick={() => onNavigate('security')}
              className="px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-500 rounded-lg transition-all shadow-sm flex items-center gap-2"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Run RLS Leak Audit</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};

import React, { useState } from 'react';
import { useTenant } from '../../context/TenantContext';
import { Palette, Globe, CheckCircle2 } from 'lucide-react';

export const WhiteLabelCustomizer: React.FC = () => {
  const { currentTenant, updateTenantBranding } = useTenant();

  if (!currentTenant) {
    return (
      <div className="p-8 text-center text-slate-500">
        Please switch to a specific agency tenant context to customize branding tokens.
      </div>
    );
  }

  const [companyName, setCompanyName] = useState(currentTenant.branding.companyName);
  const [legalName, setLegalName] = useState(currentTenant.branding.legalName || '');
  const [primaryColor, setPrimaryColor] = useState(currentTenant.branding.primaryColor);
  const [secondaryColor, setSecondaryColor] = useState(currentTenant.branding.secondaryColor);
  const [accentColor, setAccentColor] = useState(currentTenant.branding.accentColor);
  const [officeAddress, setOfficeAddress] = useState(currentTenant.branding.officeAddress || '');
  const [contactEmail, setContactEmail] = useState(currentTenant.branding.contactEmail || '');
  const [invoiceHeader, setInvoiceHeader] = useState(currentTenant.branding.invoiceHeaderHtml || '');
  const [invoiceFooter, setInvoiceFooter] = useState(currentTenant.branding.invoiceFooterHtml || '');

  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateTenantBranding(currentTenant.id, {
      companyName,
      legalName,
      primaryColor,
      secondaryColor,
      accentColor,
      officeAddress,
      contactEmail,
      invoiceHeaderHtml: invoiceHeader,
      invoiceFooterHtml: invoiceFooter,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-center justify-between transition-colors">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-slate-900 dark:text-white tracking-tight">White-Label Customizer & Brand Injection</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20 font-semibold">
              DYNAMIC THEME HYDRATION
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Configure CSS custom properties (--brand-primary, --brand-secondary, --brand-accent) and custom domain SSL.
          </p>
        </div>

        {savedSuccess && (
          <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-lg font-semibold animate-in fade-in">
            <CheckCircle2 className="w-4 h-4" />
            <span>Theme Tokens Injected Successfully!</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Branding Form */}
        <form onSubmit={handleSave} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 text-xs shadow-sm transition-colors">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Palette className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              <span>Agency Brand Tokens</span>
            </h3>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1">Company Display Name</label>
              <input
                type="text"
                value={companyName}
                onChange={e => setCompanyName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
                required
              />
            </div>
            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1">Legal Entity Name</label>
              <input
                type="text"
                value={legalName}
                onChange={e => setLegalName(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Color Pickers */}
          <div className="grid grid-cols-3 gap-3 p-3 bg-slate-50 dark:bg-slate-950 rounded-lg border border-slate-200 dark:border-slate-800">
            <div>
              <label className="block text-slate-600 dark:text-slate-400 text-[11px] mb-1 font-mono">--brand-primary</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={primaryColor}
                  onChange={e => setPrimaryColor(e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer border border-slate-300 dark:border-slate-700 bg-transparent"
                />
                <span className="font-mono text-slate-800 dark:text-slate-300">{primaryColor}</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 text-[11px] mb-1 font-mono">--brand-secondary</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={secondaryColor}
                  onChange={e => setSecondaryColor(e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer border border-slate-300 dark:border-slate-700 bg-transparent"
                />
                <span className="font-mono text-slate-800 dark:text-slate-300">{secondaryColor}</span>
              </div>
            </div>

            <div>
              <label className="block text-slate-600 dark:text-slate-400 text-[11px] mb-1 font-mono">--brand-accent</label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={accentColor}
                  onChange={e => setAccentColor(e.target.value)}
                  className="w-8 h-8 rounded cursor-pointer border border-slate-300 dark:border-slate-700 bg-transparent"
                />
                <span className="font-mono text-slate-800 dark:text-slate-300">{accentColor}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1">Support Email</label>
              <input
                type="email"
                value={contactEmail}
                onChange={e => setContactEmail(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
              />
            </div>
            <div>
              <label className="block text-slate-600 dark:text-slate-400 mb-1">Headquarters Office Address</label>
              <input
                type="text"
                value={officeAddress}
                onChange={e => setOfficeAddress(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          <div>
            <label className="block text-slate-600 dark:text-slate-400 mb-1">Invoice Header Banner Text</label>
            <input
              type="text"
              value={invoiceHeader}
              onChange={e => setInvoiceHeader(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
            />
          </div>

          <div>
            <label className="block text-slate-600 dark:text-slate-400 mb-1">Invoice Footer Disclaimer / Terms</label>
            <textarea
              rows={2}
              value={invoiceFooter}
              onChange={e => setInvoiceFooter(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded px-2.5 py-1.5 text-slate-900 dark:text-white"
            />
          </div>

          <div className="pt-2 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2 text-white font-semibold rounded-lg shadow-sm transition-all"
              style={{ backgroundColor: primaryColor }}
            >
              Apply White-Label Tokens
            </button>
          </div>
        </form>

        {/* Right: Live Preview Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4 shadow-sm transition-colors">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3 flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Globe className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Live White-Label Portal Preview</span>
            </h3>
            <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-semibold">DNS Verified</span>
          </div>

          {/* Simulated Agency Portal Card */}
          <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-inner space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center font-bold text-white text-lg shadow"
                  style={{ backgroundColor: primaryColor }}
                >
                  {companyName.charAt(0)}
                </div>
                <div>
                  <div className="font-bold text-slate-900 dark:text-white text-sm">{companyName}</div>
                  <div className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                    {currentTenant.customDomain || `${currentTenant.slug}.shahporan.com`}
                  </div>
                </div>
              </div>

              <div
                className="px-3 py-1 rounded-md text-xs font-semibold text-white shadow-sm"
                style={{ backgroundColor: primaryColor }}
              >
                Book Travel
              </div>
            </div>

            <div className="text-xs space-y-1">
              <div className="font-semibold text-slate-900 dark:text-white">Invoice & Ticket Header Preview:</div>
              <div className="p-3 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800/80 text-[11px] text-slate-600 dark:text-slate-400 font-mono">
                {invoiceHeader || 'No custom header configured.'}
              </div>
            </div>

            <div className="text-xs space-y-1">
              <div className="font-semibold text-slate-900 dark:text-white">Disclaimer & Footer Preview:</div>
              <div className="p-3 bg-white dark:bg-slate-900 rounded border border-slate-200 dark:border-slate-800/80 text-[11px] text-slate-600 dark:text-slate-400 font-mono">
                {invoiceFooter || 'No custom footer configured.'}
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between text-[11px] font-mono text-slate-500 border-t border-slate-200 dark:border-slate-800">
              <span>SSL: Cloudflare Custom Hostname</span>
              <span>TLS 1.3 Strict</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
